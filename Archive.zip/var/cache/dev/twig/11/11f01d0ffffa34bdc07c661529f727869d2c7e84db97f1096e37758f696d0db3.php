<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_81df1080c3b938c33a61355c48b0fd5d046840b737c3087abbd6b9b8572eef50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eefc40c951a042c8ecc2301f98e3bb543cd5f59d6b7a74c0cdd942f9c7a2fe1a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eefc40c951a042c8ecc2301f98e3bb543cd5f59d6b7a74c0cdd942f9c7a2fe1a->enter($__internal_eefc40c951a042c8ecc2301f98e3bb543cd5f59d6b7a74c0cdd942f9c7a2fe1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_35b676e620e282f9dd417b50d40c5cc6fc28e640d6e9a4486f10494c16223c6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35b676e620e282f9dd417b50d40c5cc6fc28e640d6e9a4486f10494c16223c6b->enter($__internal_35b676e620e282f9dd417b50d40c5cc6fc28e640d6e9a4486f10494c16223c6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eefc40c951a042c8ecc2301f98e3bb543cd5f59d6b7a74c0cdd942f9c7a2fe1a->leave($__internal_eefc40c951a042c8ecc2301f98e3bb543cd5f59d6b7a74c0cdd942f9c7a2fe1a_prof);

        
        $__internal_35b676e620e282f9dd417b50d40c5cc6fc28e640d6e9a4486f10494c16223c6b->leave($__internal_35b676e620e282f9dd417b50d40c5cc6fc28e640d6e9a4486f10494c16223c6b_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_64c491ada1143dee73b005139ffd0aa78bf467c779a3aef32e4334c2bc679243 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_64c491ada1143dee73b005139ffd0aa78bf467c779a3aef32e4334c2bc679243->enter($__internal_64c491ada1143dee73b005139ffd0aa78bf467c779a3aef32e4334c2bc679243_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_1ceda36cdc14c8f4210ce7a4cb58078df5b44e62ed39a2f26d18b2bfab3e3aae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ceda36cdc14c8f4210ce7a4cb58078df5b44e62ed39a2f26d18b2bfab3e3aae->enter($__internal_1ceda36cdc14c8f4210ce7a4cb58078df5b44e62ed39a2f26d18b2bfab3e3aae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_1ceda36cdc14c8f4210ce7a4cb58078df5b44e62ed39a2f26d18b2bfab3e3aae->leave($__internal_1ceda36cdc14c8f4210ce7a4cb58078df5b44e62ed39a2f26d18b2bfab3e3aae_prof);

        
        $__internal_64c491ada1143dee73b005139ffd0aa78bf467c779a3aef32e4334c2bc679243->leave($__internal_64c491ada1143dee73b005139ffd0aa78bf467c779a3aef32e4334c2bc679243_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_d0f15b6c87bf17fd2271cf6dd4e2c6034af1ba3e4f2c0afa24665239cc51ad01 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d0f15b6c87bf17fd2271cf6dd4e2c6034af1ba3e4f2c0afa24665239cc51ad01->enter($__internal_d0f15b6c87bf17fd2271cf6dd4e2c6034af1ba3e4f2c0afa24665239cc51ad01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_1385d5c6fd91450544c74540902151fa2cb1c8aee14877b0e1cef6d69aa4cf96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1385d5c6fd91450544c74540902151fa2cb1c8aee14877b0e1cef6d69aa4cf96->enter($__internal_1385d5c6fd91450544c74540902151fa2cb1c8aee14877b0e1cef6d69aa4cf96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_1385d5c6fd91450544c74540902151fa2cb1c8aee14877b0e1cef6d69aa4cf96->leave($__internal_1385d5c6fd91450544c74540902151fa2cb1c8aee14877b0e1cef6d69aa4cf96_prof);

        
        $__internal_d0f15b6c87bf17fd2271cf6dd4e2c6034af1ba3e4f2c0afa24665239cc51ad01->leave($__internal_d0f15b6c87bf17fd2271cf6dd4e2c6034af1ba3e4f2c0afa24665239cc51ad01_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_54052bc573f222d0a957956f5ecf4488e6b34710497113b6ee5de35bc757d2b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54052bc573f222d0a957956f5ecf4488e6b34710497113b6ee5de35bc757d2b8->enter($__internal_54052bc573f222d0a957956f5ecf4488e6b34710497113b6ee5de35bc757d2b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_eaae5ead79e08197a7f7a9fdc477cc35137a4f106992e89e2e8cb0315c73efa2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eaae5ead79e08197a7f7a9fdc477cc35137a4f106992e89e2e8cb0315c73efa2->enter($__internal_eaae5ead79e08197a7f7a9fdc477cc35137a4f106992e89e2e8cb0315c73efa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_eaae5ead79e08197a7f7a9fdc477cc35137a4f106992e89e2e8cb0315c73efa2->leave($__internal_eaae5ead79e08197a7f7a9fdc477cc35137a4f106992e89e2e8cb0315c73efa2_prof);

        
        $__internal_54052bc573f222d0a957956f5ecf4488e6b34710497113b6ee5de35bc757d2b8->leave($__internal_54052bc573f222d0a957956f5ecf4488e6b34710497113b6ee5de35bc757d2b8_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
