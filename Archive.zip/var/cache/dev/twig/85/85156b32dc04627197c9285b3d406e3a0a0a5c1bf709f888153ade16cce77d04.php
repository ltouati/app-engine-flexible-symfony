<?php

/* TwigBundle:Exception:traces.xml.twig */
class __TwigTemplate_1df8ae274ccf9c1a0c96c3cce3c911003abb748883a77e78383af6720f8874ed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e690be9d410ef7f7d6c859e4e94e2f6ed0d8233e262916bd1ff05e050d90b083 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e690be9d410ef7f7d6c859e4e94e2f6ed0d8233e262916bd1ff05e050d90b083->enter($__internal_e690be9d410ef7f7d6c859e4e94e2f6ed0d8233e262916bd1ff05e050d90b083_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:traces.xml.twig"));

        $__internal_60790af5f54f647e8359713ac0b37007ad2f6c4d91c2ca5bb45035d31d97329a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60790af5f54f647e8359713ac0b37007ad2f6c4d91c2ca5bb45035d31d97329a->enter($__internal_60790af5f54f647e8359713ac0b37007ad2f6c4d91c2ca5bb45035d31d97329a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:traces.xml.twig"));

        // line 1
        echo "        <traces>
";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "trace", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
            // line 3
            echo "            <trace>
";
            // line 4
            $this->loadTemplate("@Twig/Exception/trace.txt.twig", "TwigBundle:Exception:traces.xml.twig", 4)->display(array("trace" => $context["trace"]));
            // line 5
            echo "
            </trace>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "        </traces>
";
        
        $__internal_e690be9d410ef7f7d6c859e4e94e2f6ed0d8233e262916bd1ff05e050d90b083->leave($__internal_e690be9d410ef7f7d6c859e4e94e2f6ed0d8233e262916bd1ff05e050d90b083_prof);

        
        $__internal_60790af5f54f647e8359713ac0b37007ad2f6c4d91c2ca5bb45035d31d97329a->leave($__internal_60790af5f54f647e8359713ac0b37007ad2f6c4d91c2ca5bb45035d31d97329a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:traces.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 8,  37 => 5,  35 => 4,  32 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("        <traces>
{% for trace in exception.trace %}
            <trace>
{% include '@Twig/Exception/trace.txt.twig' with { 'trace': trace } only %}

            </trace>
{% endfor %}
        </traces>
", "TwigBundle:Exception:traces.xml.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/traces.xml.twig");
    }
}
