<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_2f2313d89515cc030494b1927b46bb749b14b448781f1118a4e14dfdcc367f42 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ac53d0800b50a2e28e6427fabdc4ef5fdaa687cb9df75ef36b1168987659b83e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ac53d0800b50a2e28e6427fabdc4ef5fdaa687cb9df75ef36b1168987659b83e->enter($__internal_ac53d0800b50a2e28e6427fabdc4ef5fdaa687cb9df75ef36b1168987659b83e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_804630058eb9edc0c4aeef9a64c28dd8d9474a7b32e6ebdd16a5884315b68c2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_804630058eb9edc0c4aeef9a64c28dd8d9474a7b32e6ebdd16a5884315b68c2d->enter($__internal_804630058eb9edc0c4aeef9a64c28dd8d9474a7b32e6ebdd16a5884315b68c2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_ac53d0800b50a2e28e6427fabdc4ef5fdaa687cb9df75ef36b1168987659b83e->leave($__internal_ac53d0800b50a2e28e6427fabdc4ef5fdaa687cb9df75ef36b1168987659b83e_prof);

        
        $__internal_804630058eb9edc0c4aeef9a64c28dd8d9474a7b32e6ebdd16a5884315b68c2d->leave($__internal_804630058eb9edc0c4aeef9a64c28dd8d9474a7b32e6ebdd16a5884315b68c2d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.atom.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
