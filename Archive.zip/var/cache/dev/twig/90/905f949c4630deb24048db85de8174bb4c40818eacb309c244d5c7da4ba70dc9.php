<?php

/* :default:homepage.html.twig */
class __TwigTemplate_1af1f647a53f667b04f4c0f238d12900da80b01a1326f753a4770d8f420b060a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:homepage.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'footer' => array($this, 'block_footer'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a2e2243c18dfed74273823c808ed1b63337c864329de233ec8578a3d042a68c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a2e2243c18dfed74273823c808ed1b63337c864329de233ec8578a3d042a68c->enter($__internal_9a2e2243c18dfed74273823c808ed1b63337c864329de233ec8578a3d042a68c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:homepage.html.twig"));

        $__internal_65cb9443338fccf6b1b2f3f0bcc796c38eaf2141749f414fd61c016c81b31a51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65cb9443338fccf6b1b2f3f0bcc796c38eaf2141749f414fd61c016c81b31a51->enter($__internal_65cb9443338fccf6b1b2f3f0bcc796c38eaf2141749f414fd61c016c81b31a51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9a2e2243c18dfed74273823c808ed1b63337c864329de233ec8578a3d042a68c->leave($__internal_9a2e2243c18dfed74273823c808ed1b63337c864329de233ec8578a3d042a68c_prof);

        
        $__internal_65cb9443338fccf6b1b2f3f0bcc796c38eaf2141749f414fd61c016c81b31a51->leave($__internal_65cb9443338fccf6b1b2f3f0bcc796c38eaf2141749f414fd61c016c81b31a51_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_e2b5ad6f3a531b06d552c80f71242fdb47302702c0f0b768c053ed38849dd8a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e2b5ad6f3a531b06d552c80f71242fdb47302702c0f0b768c053ed38849dd8a5->enter($__internal_e2b5ad6f3a531b06d552c80f71242fdb47302702c0f0b768c053ed38849dd8a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_de93939d9c130c123f2511564f74842cdefc443a6731a686994afbefc6619add = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de93939d9c130c123f2511564f74842cdefc443a6731a686994afbefc6619add->enter($__internal_de93939d9c130c123f2511564f74842cdefc443a6731a686994afbefc6619add_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "homepage";
        
        $__internal_de93939d9c130c123f2511564f74842cdefc443a6731a686994afbefc6619add->leave($__internal_de93939d9c130c123f2511564f74842cdefc443a6731a686994afbefc6619add_prof);

        
        $__internal_e2b5ad6f3a531b06d552c80f71242fdb47302702c0f0b768c053ed38849dd8a5->leave($__internal_e2b5ad6f3a531b06d552c80f71242fdb47302702c0f0b768c053ed38849dd8a5_prof);

    }

    // line 9
    public function block_header($context, array $blocks = array())
    {
        $__internal_0e2f1a346e146ba0e51c31fc7f8eb36c250be129a2690e405618fbe273dbfb1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e2f1a346e146ba0e51c31fc7f8eb36c250be129a2690e405618fbe273dbfb1b->enter($__internal_0e2f1a346e146ba0e51c31fc7f8eb36c250be129a2690e405618fbe273dbfb1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_e167c1f7d56b74abe802acd11e76963f3738c9013ce8752feb6e18744c8bb0b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e167c1f7d56b74abe802acd11e76963f3738c9013ce8752feb6e18744c8bb0b9->enter($__internal_e167c1f7d56b74abe802acd11e76963f3738c9013ce8752feb6e18744c8bb0b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        
        $__internal_e167c1f7d56b74abe802acd11e76963f3738c9013ce8752feb6e18744c8bb0b9->leave($__internal_e167c1f7d56b74abe802acd11e76963f3738c9013ce8752feb6e18744c8bb0b9_prof);

        
        $__internal_0e2f1a346e146ba0e51c31fc7f8eb36c250be129a2690e405618fbe273dbfb1b->leave($__internal_0e2f1a346e146ba0e51c31fc7f8eb36c250be129a2690e405618fbe273dbfb1b_prof);

    }

    // line 10
    public function block_footer($context, array $blocks = array())
    {
        $__internal_31f5028101a8d862716b5b9be398642d8d334ca1286b67b3c2625d7dd2c561f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_31f5028101a8d862716b5b9be398642d8d334ca1286b67b3c2625d7dd2c561f7->enter($__internal_31f5028101a8d862716b5b9be398642d8d334ca1286b67b3c2625d7dd2c561f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_4a4fd67e4841dfb18a0d2e1f79ce6c1c3d0d12e1d4f3ec493fcbf97ec6cec96c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a4fd67e4841dfb18a0d2e1f79ce6c1c3d0d12e1d4f3ec493fcbf97ec6cec96c->enter($__internal_4a4fd67e4841dfb18a0d2e1f79ce6c1c3d0d12e1d4f3ec493fcbf97ec6cec96c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_4a4fd67e4841dfb18a0d2e1f79ce6c1c3d0d12e1d4f3ec493fcbf97ec6cec96c->leave($__internal_4a4fd67e4841dfb18a0d2e1f79ce6c1c3d0d12e1d4f3ec493fcbf97ec6cec96c_prof);

        
        $__internal_31f5028101a8d862716b5b9be398642d8d334ca1286b67b3c2625d7dd2c561f7->leave($__internal_31f5028101a8d862716b5b9be398642d8d334ca1286b67b3c2625d7dd2c561f7_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_a0a6c544ef72953d2c2dccd53cdd9802eaa86c76f5a63351544fa8a57c56526c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0a6c544ef72953d2c2dccd53cdd9802eaa86c76f5a63351544fa8a57c56526c->enter($__internal_a0a6c544ef72953d2c2dccd53cdd9802eaa86c76f5a63351544fa8a57c56526c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b2430980f8bc53a4caef373e5724db9e0606cc76424a5cf1adbb380da5c376c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2430980f8bc53a4caef373e5724db9e0606cc76424a5cf1adbb380da5c376c8->enter($__internal_b2430980f8bc53a4caef373e5724db9e0606cc76424a5cf1adbb380da5c376c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "    <div class=\"page-header\">
        <h1>";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.homepage");
        echo "</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.browse_app");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
                        <i class=\"fa fa-users\" aria-hidden=\"true\"></i> ";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.browse_app"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>

        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.browse_admin");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">
                        <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.browse_admin"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>
    </div>
";
        
        $__internal_b2430980f8bc53a4caef373e5724db9e0606cc76424a5cf1adbb380da5c376c8->leave($__internal_b2430980f8bc53a4caef373e5724db9e0606cc76424a5cf1adbb380da5c376c8_prof);

        
        $__internal_a0a6c544ef72953d2c2dccd53cdd9802eaa86c76f5a63351544fa8a57c56526c->leave($__internal_a0a6c544ef72953d2c2dccd53cdd9802eaa86c76f5a63351544fa8a57c56526c_prof);

    }

    public function getTemplateName()
    {
        return ":default:homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 38,  145 => 37,  139 => 34,  127 => 25,  123 => 24,  117 => 21,  107 => 14,  104 => 13,  95 => 12,  78 => 10,  61 => 9,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'homepage' %}

{#
    the homepage is a special page which displays neither a header nor a footer.
    this is done with the 'trick' of defining empty Twig blocks without any content
#}
{% block header %}{% endblock %}
{% block footer %}{% endblock %}

{% block body %}
    <div class=\"page-header\">
        <h1>{{ 'title.homepage'|trans|raw }}</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    {{ 'help.browse_app'|trans|raw }}
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"{{ path('blog_index') }}\">
                        <i class=\"fa fa-users\" aria-hidden=\"true\"></i> {{ 'action.browse_app'|trans }}
                    </a>
                </p>
            </div>
        </div>

        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    {{ 'help.browse_admin'|trans|raw }}
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"{{ path('admin_index') }}\">
                        <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'action.browse_admin'|trans }}
                    </a>
                </p>
            </div>
        </div>
    </div>
{% endblock %}
", ":default:homepage.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/default/homepage.html.twig");
    }
}
