<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_7796cc5fca08ad6c6d61efc81325eff013c35dccbbbad28f4ab4494a3bb65bb0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cdde0b74478ccf933dd992188eec2decc40ab47e06f9befc865d82890fa102d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cdde0b74478ccf933dd992188eec2decc40ab47e06f9befc865d82890fa102d0->enter($__internal_cdde0b74478ccf933dd992188eec2decc40ab47e06f9befc865d82890fa102d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_865a7aeb089e6fbaa4a37c2a86f5a699835fd7f83ca7956ce26b7291c0358000 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_865a7aeb089e6fbaa4a37c2a86f5a699835fd7f83ca7956ce26b7291c0358000->enter($__internal_865a7aeb089e6fbaa4a37c2a86f5a699835fd7f83ca7956ce26b7291c0358000_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_cdde0b74478ccf933dd992188eec2decc40ab47e06f9befc865d82890fa102d0->leave($__internal_cdde0b74478ccf933dd992188eec2decc40ab47e06f9befc865d82890fa102d0_prof);

        
        $__internal_865a7aeb089e6fbaa4a37c2a86f5a699835fd7f83ca7956ce26b7291c0358000->leave($__internal_865a7aeb089e6fbaa4a37c2a86f5a699835fd7f83ca7956ce26b7291c0358000_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/radio_widget.html.php");
    }
}
