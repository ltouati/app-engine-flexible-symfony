<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_53189950d60db56d9f0c936a6e2de74ff5eaca1d4572f786f98ce495acda0ea5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae179f5bca419b3245be8e593ea31c3dfac38ff9bec71114fed9d498dd90799c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae179f5bca419b3245be8e593ea31c3dfac38ff9bec71114fed9d498dd90799c->enter($__internal_ae179f5bca419b3245be8e593ea31c3dfac38ff9bec71114fed9d498dd90799c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        $__internal_c62c5753ff9022ce669f250f99af192bee904243c620e02b94f5c21a08947ca1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c62c5753ff9022ce669f250f99af192bee904243c620e02b94f5c21a08947ca1->enter($__internal_c62c5753ff9022ce669f250f99af192bee904243c620e02b94f5c21a08947ca1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_ae179f5bca419b3245be8e593ea31c3dfac38ff9bec71114fed9d498dd90799c->leave($__internal_ae179f5bca419b3245be8e593ea31c3dfac38ff9bec71114fed9d498dd90799c_prof);

        
        $__internal_c62c5753ff9022ce669f250f99af192bee904243c620e02b94f5c21a08947ca1->leave($__internal_c62c5753ff9022ce669f250f99af192bee904243c620e02b94f5c21a08947ca1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
", "@Framework/Form/money_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/money_widget.html.php");
    }
}
