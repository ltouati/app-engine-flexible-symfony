<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_7816671c6e957a007a4fa9de8ea0b22d6e465cbd0a612f1c012747d346e1c73d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_249522aba119027e558dc0e6d6758c3298ccc42777ab3c85d2a0e58ecfe6d759 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_249522aba119027e558dc0e6d6758c3298ccc42777ab3c85d2a0e58ecfe6d759->enter($__internal_249522aba119027e558dc0e6d6758c3298ccc42777ab3c85d2a0e58ecfe6d759_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_873811e5fc70fbd0e32edf02983f00e6cfc364a08ff3f0f72d2e0d0cf1566d56 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_873811e5fc70fbd0e32edf02983f00e6cfc364a08ff3f0f72d2e0d0cf1566d56->enter($__internal_873811e5fc70fbd0e32edf02983f00e6cfc364a08ff3f0f72d2e0d0cf1566d56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_249522aba119027e558dc0e6d6758c3298ccc42777ab3c85d2a0e58ecfe6d759->leave($__internal_249522aba119027e558dc0e6d6758c3298ccc42777ab3c85d2a0e58ecfe6d759_prof);

        
        $__internal_873811e5fc70fbd0e32edf02983f00e6cfc364a08ff3f0f72d2e0d0cf1566d56->leave($__internal_873811e5fc70fbd0e32edf02983f00e6cfc364a08ff3f0f72d2e0d0cf1566d56_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/integer_widget.html.php");
    }
}
