<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_8f1644f9803d8e7c59cf0e305df7d5a47dd163e7a3601a13c802420b29480b6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ec0a2dd5ac095d50dde645875e88d2cf7ddda42f83a96f58b1788dd08762d91 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ec0a2dd5ac095d50dde645875e88d2cf7ddda42f83a96f58b1788dd08762d91->enter($__internal_2ec0a2dd5ac095d50dde645875e88d2cf7ddda42f83a96f58b1788dd08762d91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_5921d792d7b8669fecf99ae7655547441bebd2d281a3e24d458fb0b85364fad6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5921d792d7b8669fecf99ae7655547441bebd2d281a3e24d458fb0b85364fad6->enter($__internal_5921d792d7b8669fecf99ae7655547441bebd2d281a3e24d458fb0b85364fad6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_2ec0a2dd5ac095d50dde645875e88d2cf7ddda42f83a96f58b1788dd08762d91->leave($__internal_2ec0a2dd5ac095d50dde645875e88d2cf7ddda42f83a96f58b1788dd08762d91_prof);

        
        $__internal_5921d792d7b8669fecf99ae7655547441bebd2d281a3e24d458fb0b85364fad6->leave($__internal_5921d792d7b8669fecf99ae7655547441bebd2d281a3e24d458fb0b85364fad6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
