<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_d31d5cb4a2ca4099c23eae09c8240e694777ee6d4a0847df86a548edcd9a4d4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_912d4c1d37cacebde0bc28747523eb97aac405097324bcdf3144883c5810c332 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_912d4c1d37cacebde0bc28747523eb97aac405097324bcdf3144883c5810c332->enter($__internal_912d4c1d37cacebde0bc28747523eb97aac405097324bcdf3144883c5810c332_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_3d6fdf8b94eb39a2546e588cf0a63ca9306638c3eed257a28eefb59e4d53896f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d6fdf8b94eb39a2546e588cf0a63ca9306638c3eed257a28eefb59e4d53896f->enter($__internal_3d6fdf8b94eb39a2546e588cf0a63ca9306638c3eed257a28eefb59e4d53896f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_912d4c1d37cacebde0bc28747523eb97aac405097324bcdf3144883c5810c332->leave($__internal_912d4c1d37cacebde0bc28747523eb97aac405097324bcdf3144883c5810c332_prof);

        
        $__internal_3d6fdf8b94eb39a2546e588cf0a63ca9306638c3eed257a28eefb59e4d53896f->leave($__internal_3d6fdf8b94eb39a2546e588cf0a63ca9306638c3eed257a28eefb59e4d53896f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/checkbox_widget.html.php");
    }
}
