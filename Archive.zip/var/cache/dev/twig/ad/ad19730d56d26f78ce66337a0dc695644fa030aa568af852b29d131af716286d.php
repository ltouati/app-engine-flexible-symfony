<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_cbe728c71ceed6e5fd92ad8f6c37c3b78335aa183da0944ca41d9e8db8792b28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c0a119cf39bf4795f622e783537d8b87b42a8f3f8aead11bc08631d3b8af4fa0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c0a119cf39bf4795f622e783537d8b87b42a8f3f8aead11bc08631d3b8af4fa0->enter($__internal_c0a119cf39bf4795f622e783537d8b87b42a8f3f8aead11bc08631d3b8af4fa0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_2e62b884b603f12249a00e7a13dc92ea52238e87b4ad0cac53712813bf503bc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e62b884b603f12249a00e7a13dc92ea52238e87b4ad0cac53712813bf503bc1->enter($__internal_2e62b884b603f12249a00e7a13dc92ea52238e87b4ad0cac53712813bf503bc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_c0a119cf39bf4795f622e783537d8b87b42a8f3f8aead11bc08631d3b8af4fa0->leave($__internal_c0a119cf39bf4795f622e783537d8b87b42a8f3f8aead11bc08631d3b8af4fa0_prof);

        
        $__internal_2e62b884b603f12249a00e7a13dc92ea52238e87b4ad0cac53712813bf503bc1->leave($__internal_2e62b884b603f12249a00e7a13dc92ea52238e87b4ad0cac53712813bf503bc1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/number_widget.html.php");
    }
}
