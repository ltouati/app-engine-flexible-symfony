<?php

/* TwigBundle:Exception:error500.html.twig */
class __TwigTemplate_a495f51b06eba34212d262c3716bfa050f647d73a62621e265cecc940fe4ea37 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error500.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6730253c18bf95e6bcf180fdb5246ab694f10a7b749fc4f82a1e2ab78fdfc55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6730253c18bf95e6bcf180fdb5246ab694f10a7b749fc4f82a1e2ab78fdfc55->enter($__internal_d6730253c18bf95e6bcf180fdb5246ab694f10a7b749fc4f82a1e2ab78fdfc55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error500.html.twig"));

        $__internal_7b331b84485e959b8d77dbc37e9fd9f87025f2360eb903da2ac0c79deb2ced2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b331b84485e959b8d77dbc37e9fd9f87025f2360eb903da2ac0c79deb2ced2a->enter($__internal_7b331b84485e959b8d77dbc37e9fd9f87025f2360eb903da2ac0c79deb2ced2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error500.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d6730253c18bf95e6bcf180fdb5246ab694f10a7b749fc4f82a1e2ab78fdfc55->leave($__internal_d6730253c18bf95e6bcf180fdb5246ab694f10a7b749fc4f82a1e2ab78fdfc55_prof);

        
        $__internal_7b331b84485e959b8d77dbc37e9fd9f87025f2360eb903da2ac0c79deb2ced2a->leave($__internal_7b331b84485e959b8d77dbc37e9fd9f87025f2360eb903da2ac0c79deb2ced2a_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_6983fbdeaf79a1af63fbae0f4f2c64a9aa6084e8f75065c84a25172f82ca14ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6983fbdeaf79a1af63fbae0f4f2c64a9aa6084e8f75065c84a25172f82ca14ed->enter($__internal_6983fbdeaf79a1af63fbae0f4f2c64a9aa6084e8f75065c84a25172f82ca14ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_274e6978aec462b7658d517fdae7e7a6433c2d4b8fa5a4082088aad6fc2bc16b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_274e6978aec462b7658d517fdae7e7a6433c2d4b8fa5a4082088aad6fc2bc16b->enter($__internal_274e6978aec462b7658d517fdae7e7a6433c2d4b8fa5a4082088aad6fc2bc16b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_274e6978aec462b7658d517fdae7e7a6433c2d4b8fa5a4082088aad6fc2bc16b->leave($__internal_274e6978aec462b7658d517fdae7e7a6433c2d4b8fa5a4082088aad6fc2bc16b_prof);

        
        $__internal_6983fbdeaf79a1af63fbae0f4f2c64a9aa6084e8f75065c84a25172f82ca14ed->leave($__internal_6983fbdeaf79a1af63fbae0f4f2c64a9aa6084e8f75065c84a25172f82ca14ed_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_8efa62c08ba372377a438cfee88224ecfa00872f8e424e546c7c5e3bcebf0db7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8efa62c08ba372377a438cfee88224ecfa00872f8e424e546c7c5e3bcebf0db7->enter($__internal_8efa62c08ba372377a438cfee88224ecfa00872f8e424e546c7c5e3bcebf0db7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_1ad123f6a6211983a6be6729e2a70526c6311b37d40c0a72b73afc47605079cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ad123f6a6211983a6be6729e2a70526c6311b37d40c0a72b73afc47605079cf->enter($__internal_1ad123f6a6211983a6be6729e2a70526c6311b37d40c0a72b73afc47605079cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => 500)), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_500.description"), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_500.suggestion", array("%url%" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index")));
        echo "
    </p>
";
        
        $__internal_1ad123f6a6211983a6be6729e2a70526c6311b37d40c0a72b73afc47605079cf->leave($__internal_1ad123f6a6211983a6be6729e2a70526c6311b37d40c0a72b73afc47605079cf_prof);

        
        $__internal_8efa62c08ba372377a438cfee88224ecfa00872f8e424e546c7c5e3bcebf0db7->leave($__internal_8efa62c08ba372377a438cfee88224ecfa00872f8e424e546c7c5e3bcebf0db7_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_59e59e324f97f9bb14814097525bc9b9fa59ce126d43991ceffdc79f64d79a72 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59e59e324f97f9bb14814097525bc9b9fa59ce126d43991ceffdc79f64d79a72->enter($__internal_59e59e324f97f9bb14814097525bc9b9fa59ce126d43991ceffdc79f64d79a72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_d032b0024ff5be0c245c56e8c45a9b3431502e0d067f65d3c63bcea338a6b948 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d032b0024ff5be0c245c56e8c45a9b3431502e0d067f65d3c63bcea338a6b948->enter($__internal_d032b0024ff5be0c245c56e8c45a9b3431502e0d067f65d3c63bcea338a6b948_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_d032b0024ff5be0c245c56e8c45a9b3431502e0d067f65d3c63bcea338a6b948->leave($__internal_d032b0024ff5be0c245c56e8c45a9b3431502e0d067f65d3c63bcea338a6b948_prof);

        
        $__internal_59e59e324f97f9bb14814097525bc9b9fa59ce126d43991ceffdc79f64d79a72->leave($__internal_59e59e324f97f9bb14814097525bc9b9fa59ce126d43991ceffdc79f64d79a72_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error500.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render errors of type HTTP 500 (Internal Server Error)

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See https://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'http_error.name'|trans({ '%status_code%': 500 }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error_500.description'|trans }}
    </p>
    <p>
        {{ 'http_error_500.suggestion'|trans({ '%url%': path('blog_index') })|raw }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error500.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/TwigBundle/views/Exception/error500.html.twig");
    }
}
