<?php

/* :form:layout.html.twig */
class __TwigTemplate_b252b079cd100802a7aa2b884e66ed0e1228b575795daef8ae5916a2cb5e064f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("bootstrap_3_layout.html.twig", ":form:layout.html.twig", 1);
        $this->blocks = array(
            'form_errors' => array($this, 'block_form_errors'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "bootstrap_3_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19ed8b6496324b3c755f73088ef0801693ef7b50b849a07e8f86d0a54966626d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19ed8b6496324b3c755f73088ef0801693ef7b50b849a07e8f86d0a54966626d->enter($__internal_19ed8b6496324b3c755f73088ef0801693ef7b50b849a07e8f86d0a54966626d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":form:layout.html.twig"));

        $__internal_a026de3f12c987e26abbb6e0e06f2be953a568cd6edce648682a0fdd4c7b1e77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a026de3f12c987e26abbb6e0e06f2be953a568cd6edce648682a0fdd4c7b1e77->enter($__internal_a026de3f12c987e26abbb6e0e06f2be953a568cd6edce648682a0fdd4c7b1e77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":form:layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_19ed8b6496324b3c755f73088ef0801693ef7b50b849a07e8f86d0a54966626d->leave($__internal_19ed8b6496324b3c755f73088ef0801693ef7b50b849a07e8f86d0a54966626d_prof);

        
        $__internal_a026de3f12c987e26abbb6e0e06f2be953a568cd6edce648682a0fdd4c7b1e77->leave($__internal_a026de3f12c987e26abbb6e0e06f2be953a568cd6edce648682a0fdd4c7b1e77_prof);

    }

    // line 5
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_d4ed1b9cef68e2fdbcd6f769fb7094844862abf75683834aa6d6028079a2eb65 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4ed1b9cef68e2fdbcd6f769fb7094844862abf75683834aa6d6028079a2eb65->enter($__internal_d4ed1b9cef68e2fdbcd6f769fb7094844862abf75683834aa6d6028079a2eb65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_add8bc115375b14ce6eb4e730e5db2150c9e1cdb390b4de11fcba47cd3235d61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_add8bc115375b14ce6eb4e730e5db2150c9e1cdb390b4de11fcba47cd3235d61->enter($__internal_add8bc115375b14ce6eb4e730e5db2150c9e1cdb390b4de11fcba47cd3235d61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 6
        if ((twig_length_filter($this->env, (isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors"))) > 0)) {
            // line 7
            if ($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 8
            echo "        <ul class=\"list-unstyled\">";
            // line 9
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 11
                echo "            <li><span class=\"fa fa-exclamation-triangle\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "</ul>
        ";
            // line 14
            if ($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_add8bc115375b14ce6eb4e730e5db2150c9e1cdb390b4de11fcba47cd3235d61->leave($__internal_add8bc115375b14ce6eb4e730e5db2150c9e1cdb390b4de11fcba47cd3235d61_prof);

        
        $__internal_d4ed1b9cef68e2fdbcd6f769fb7094844862abf75683834aa6d6028079a2eb65->leave($__internal_d4ed1b9cef68e2fdbcd6f769fb7094844862abf75683834aa6d6028079a2eb65_prof);

    }

    public function getTemplateName()
    {
        return ":form:layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 14,  71 => 13,  63 => 11,  59 => 9,  57 => 8,  51 => 7,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'bootstrap_3_layout.html.twig' %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
        {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
        <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            {# use font-awesome icon library #}
            <li><span class=\"fa fa-exclamation-triangle\"></span> {{ error.message }}</li>
        {%- endfor -%}
        </ul>
        {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", ":form:layout.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/form/layout.html.twig");
    }
}
