<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_890d4aceceb0e25da6efb41efa366d1344386cab1a2c4db48b1493d63d70014a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dda0e237e8db86925ea3652e80aa8c88a1fc40697c9a29ebdfd9b45290432970 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dda0e237e8db86925ea3652e80aa8c88a1fc40697c9a29ebdfd9b45290432970->enter($__internal_dda0e237e8db86925ea3652e80aa8c88a1fc40697c9a29ebdfd9b45290432970_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_e5f45982b3d24c7dd43b7882fde704d8f53ea5b14ccf7bbb6eea6e4d06dc03ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5f45982b3d24c7dd43b7882fde704d8f53ea5b14ccf7bbb6eea6e4d06dc03ff->enter($__internal_e5f45982b3d24c7dd43b7882fde704d8f53ea5b14ccf7bbb6eea6e4d06dc03ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_dda0e237e8db86925ea3652e80aa8c88a1fc40697c9a29ebdfd9b45290432970->leave($__internal_dda0e237e8db86925ea3652e80aa8c88a1fc40697c9a29ebdfd9b45290432970_prof);

        
        $__internal_e5f45982b3d24c7dd43b7882fde704d8f53ea5b14ccf7bbb6eea6e4d06dc03ff->leave($__internal_e5f45982b3d24c7dd43b7882fde704d8f53ea5b14ccf7bbb6eea6e4d06dc03ff_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
