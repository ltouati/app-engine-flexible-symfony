<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_0e7aa329e8cc525bff7336d70482613f6cdd76af7b9068540d0c97a113773879 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5acaf160344766234325eb783f044f238386ca8adf741905ba74b363646fcb0e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5acaf160344766234325eb783f044f238386ca8adf741905ba74b363646fcb0e->enter($__internal_5acaf160344766234325eb783f044f238386ca8adf741905ba74b363646fcb0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_544b3420fb5d0b1c2915a8923524bd327ef78f906d1aca120b3e4848e3aa219d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_544b3420fb5d0b1c2915a8923524bd327ef78f906d1aca120b3e4848e3aa219d->enter($__internal_544b3420fb5d0b1c2915a8923524bd327ef78f906d1aca120b3e4848e3aa219d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_5acaf160344766234325eb783f044f238386ca8adf741905ba74b363646fcb0e->leave($__internal_5acaf160344766234325eb783f044f238386ca8adf741905ba74b363646fcb0e_prof);

        
        $__internal_544b3420fb5d0b1c2915a8923524bd327ef78f906d1aca120b3e4848e3aa219d->leave($__internal_544b3420fb5d0b1c2915a8923524bd327ef78f906d1aca120b3e4848e3aa219d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
