<?php

/* :blog:comment_form_error.html.twig */
class __TwigTemplate_e85c4d2b4f6187a0a306e246862268509488b31e395be1b7a882ec7da8614772 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":blog:comment_form_error.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1aa0eb8e1624bcc6934633dcf69ceb830d6d30942b1fa9ae418a3b20894009a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1aa0eb8e1624bcc6934633dcf69ceb830d6d30942b1fa9ae418a3b20894009a6->enter($__internal_1aa0eb8e1624bcc6934633dcf69ceb830d6d30942b1fa9ae418a3b20894009a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:comment_form_error.html.twig"));

        $__internal_3cafe481d7ef3172b611d70d66cdeb4a4e623d19ac57caa8a37c03b288d23bf7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cafe481d7ef3172b611d70d66cdeb4a4e623d19ac57caa8a37c03b288d23bf7->enter($__internal_3cafe481d7ef3172b611d70d66cdeb4a4e623d19ac57caa8a37c03b288d23bf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:comment_form_error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1aa0eb8e1624bcc6934633dcf69ceb830d6d30942b1fa9ae418a3b20894009a6->leave($__internal_1aa0eb8e1624bcc6934633dcf69ceb830d6d30942b1fa9ae418a3b20894009a6_prof);

        
        $__internal_3cafe481d7ef3172b611d70d66cdeb4a4e623d19ac57caa8a37c03b288d23bf7->leave($__internal_3cafe481d7ef3172b611d70d66cdeb4a4e623d19ac57caa8a37c03b288d23bf7_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_a2978151c6d7953dc28c385ec21fb2273f31b7b531c3ca1da5449d3be420b76c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2978151c6d7953dc28c385ec21fb2273f31b7b531c3ca1da5449d3be420b76c->enter($__internal_a2978151c6d7953dc28c385ec21fb2273f31b7b531c3ca1da5449d3be420b76c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_dc3432f4a14f87108f13041b920aff9df698aee970aac9809703a0e4408cab92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc3432f4a14f87108f13041b920aff9df698aee970aac9809703a0e4408cab92->enter($__internal_dc3432f4a14f87108f13041b920aff9df698aee970aac9809703a0e4408cab92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "comment_form_error";
        
        $__internal_dc3432f4a14f87108f13041b920aff9df698aee970aac9809703a0e4408cab92->leave($__internal_dc3432f4a14f87108f13041b920aff9df698aee970aac9809703a0e4408cab92_prof);

        
        $__internal_a2978151c6d7953dc28c385ec21fb2273f31b7b531c3ca1da5449d3be420b76c->leave($__internal_a2978151c6d7953dc28c385ec21fb2273f31b7b531c3ca1da5449d3be420b76c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_d1728e47093727f3d411a2584d270b2ff9df30214db4be5bf332062fa3f64da1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1728e47093727f3d411a2584d270b2ff9df30214db4be5bf332062fa3f64da1->enter($__internal_d1728e47093727f3d411a2584d270b2ff9df30214db4be5bf332062fa3f64da1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_d503af4daa237222023f82b90f5adc1e9f4a079409d16c5a403c89ddb4bef11e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d503af4daa237222023f82b90f5adc1e9f4a079409d16c5a403c89ddb4bef11e->enter($__internal_d503af4daa237222023f82b90f5adc1e9f4a079409d16c5a403c89ddb4bef11e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.comment_error"), "html", null, true);
        echo "</h1>

    <div class=\"well\">
        ";
        // line 9
        echo twig_include($this->env, $context, "blog/_comment_form.html.twig");
        echo "
    </div>
";
        
        $__internal_d503af4daa237222023f82b90f5adc1e9f4a079409d16c5a403c89ddb4bef11e->leave($__internal_d503af4daa237222023f82b90f5adc1e9f4a079409d16c5a403c89ddb4bef11e_prof);

        
        $__internal_d1728e47093727f3d411a2584d270b2ff9df30214db4be5bf332062fa3f64da1->leave($__internal_d1728e47093727f3d411a2584d270b2ff9df30214db4be5bf332062fa3f64da1_prof);

    }

    public function getTemplateName()
    {
        return ":blog:comment_form_error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 9,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'comment_form_error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'title.comment_error'|trans }}</h1>

    <div class=\"well\">
        {{ include('blog/_comment_form.html.twig') }}
    </div>
{% endblock %}
", ":blog:comment_form_error.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/blog/comment_form_error.html.twig");
    }
}
