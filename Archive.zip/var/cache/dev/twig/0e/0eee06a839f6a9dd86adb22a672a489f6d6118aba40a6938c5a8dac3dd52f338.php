<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_2a5bc1e7f3673e2abaed0508cd565169b863c38cbaff2934e7c0cedd59b2adbf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b77c63a4dbd13ae99b368a26a3186c477a62b0cf8d98f3be43703833cde8ed0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b77c63a4dbd13ae99b368a26a3186c477a62b0cf8d98f3be43703833cde8ed0->enter($__internal_5b77c63a4dbd13ae99b368a26a3186c477a62b0cf8d98f3be43703833cde8ed0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_c84a985bff6e64d1dc3e9244b2ec6eb8ba605060c42932e502272d0e49c9b3bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c84a985bff6e64d1dc3e9244b2ec6eb8ba605060c42932e502272d0e49c9b3bb->enter($__internal_c84a985bff6e64d1dc3e9244b2ec6eb8ba605060c42932e502272d0e49c9b3bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_5b77c63a4dbd13ae99b368a26a3186c477a62b0cf8d98f3be43703833cde8ed0->leave($__internal_5b77c63a4dbd13ae99b368a26a3186c477a62b0cf8d98f3be43703833cde8ed0_prof);

        
        $__internal_c84a985bff6e64d1dc3e9244b2ec6eb8ba605060c42932e502272d0e49c9b3bb->leave($__internal_c84a985bff6e64d1dc3e9244b2ec6eb8ba605060c42932e502272d0e49c9b3bb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
