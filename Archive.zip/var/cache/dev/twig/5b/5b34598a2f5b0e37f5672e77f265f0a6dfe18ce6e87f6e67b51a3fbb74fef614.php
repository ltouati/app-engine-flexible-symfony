<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_adde242bdeefb4c0e97db8a5b041f28ae184a2235f470b633a35427d66356b2f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4922d20fb67fc3e9e55ee0b8f34b6bdb73daa047552ee71306984fb700552328 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4922d20fb67fc3e9e55ee0b8f34b6bdb73daa047552ee71306984fb700552328->enter($__internal_4922d20fb67fc3e9e55ee0b8f34b6bdb73daa047552ee71306984fb700552328_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_53851ee080071b079169b7d8ca405585f3c93d502c661062f911c470fc1e6339 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53851ee080071b079169b7d8ca405585f3c93d502c661062f911c470fc1e6339->enter($__internal_53851ee080071b079169b7d8ca405585f3c93d502c661062f911c470fc1e6339_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_4922d20fb67fc3e9e55ee0b8f34b6bdb73daa047552ee71306984fb700552328->leave($__internal_4922d20fb67fc3e9e55ee0b8f34b6bdb73daa047552ee71306984fb700552328_prof);

        
        $__internal_53851ee080071b079169b7d8ca405585f3c93d502c661062f911c470fc1e6339->leave($__internal_53851ee080071b079169b7d8ca405585f3c93d502c661062f911c470fc1e6339_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
