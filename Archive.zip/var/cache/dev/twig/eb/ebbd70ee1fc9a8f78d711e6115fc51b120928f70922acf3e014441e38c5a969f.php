<?php

/* blog/_rss.html.twig */
class __TwigTemplate_3cbabe78c9fb2e2734c83f8fd7db16bb9de894b4d5df640d404f4436d0f86cb2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_accc1bb9fca44cc4f02cdeca5ce4730364eaf5475e66a87243126437147ff800 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_accc1bb9fca44cc4f02cdeca5ce4730364eaf5475e66a87243126437147ff800->enter($__internal_accc1bb9fca44cc4f02cdeca5ce4730364eaf5475e66a87243126437147ff800_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/_rss.html.twig"));

        $__internal_e1143ce4df6b206f796cae27f768c42c1829f35d5014e7682184279d0583d76a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1143ce4df6b206f796cae27f768c42c1829f35d5014e7682184279d0583d76a->enter($__internal_e1143ce4df6b206f796cae27f768c42c1829f35d5014e7682184279d0583d76a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/_rss.html.twig"));

        // line 1
        echo "<div class=\"section rss\">
    <a href=\"";
        // line 2
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> ";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.rss"), "html", null, true);
        echo "
    </a>
</div>
";
        
        $__internal_accc1bb9fca44cc4f02cdeca5ce4730364eaf5475e66a87243126437147ff800->leave($__internal_accc1bb9fca44cc4f02cdeca5ce4730364eaf5475e66a87243126437147ff800_prof);

        
        $__internal_e1143ce4df6b206f796cae27f768c42c1829f35d5014e7682184279d0583d76a->leave($__internal_e1143ce4df6b206f796cae27f768c42c1829f35d5014e7682184279d0583d76a_prof);

    }

    public function getTemplateName()
    {
        return "blog/_rss.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"section rss\">
    <a href=\"{{ path('blog_rss') }}\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> {{ 'menu.rss'|trans }}
    </a>
</div>
", "blog/_rss.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/blog/_rss.html.twig");
    }
}
