<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_b3f6cd6aab94219f61d444b7f04e355ffaafe95ff3b18849690887c29bd0750d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b66f576fa504553c65b669bb607fe952d3e399ee4be4b4f896411d8ac0b3f62 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b66f576fa504553c65b669bb607fe952d3e399ee4be4b4f896411d8ac0b3f62->enter($__internal_8b66f576fa504553c65b669bb607fe952d3e399ee4be4b4f896411d8ac0b3f62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_9e52fce70bf77299ce42d876f1331c2ee76f581136dad933ffe644c108759469 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e52fce70bf77299ce42d876f1331c2ee76f581136dad933ffe644c108759469->enter($__internal_9e52fce70bf77299ce42d876f1331c2ee76f581136dad933ffe644c108759469_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_8b66f576fa504553c65b669bb607fe952d3e399ee4be4b4f896411d8ac0b3f62->leave($__internal_8b66f576fa504553c65b669bb607fe952d3e399ee4be4b4f896411d8ac0b3f62_prof);

        
        $__internal_9e52fce70bf77299ce42d876f1331c2ee76f581136dad933ffe644c108759469->leave($__internal_9e52fce70bf77299ce42d876f1331c2ee76f581136dad933ffe644c108759469_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
