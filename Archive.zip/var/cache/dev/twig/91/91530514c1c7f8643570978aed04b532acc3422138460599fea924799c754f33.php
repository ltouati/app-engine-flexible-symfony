<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_81b73ece2e62ca84da2ba6ef611bfa23a52a634e5036e5e583f8368819d5e4c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12ca85ac8e926ea952c0d6fd878450b444ec5e4734c37c52a96e8cd4ae05054b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12ca85ac8e926ea952c0d6fd878450b444ec5e4734c37c52a96e8cd4ae05054b->enter($__internal_12ca85ac8e926ea952c0d6fd878450b444ec5e4734c37c52a96e8cd4ae05054b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_cdc2a6ee3bec88a055f99f9ff5d0c57c7bfe306fcee4304977c7a4089d556453 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdc2a6ee3bec88a055f99f9ff5d0c57c7bfe306fcee4304977c7a4089d556453->enter($__internal_cdc2a6ee3bec88a055f99f9ff5d0c57c7bfe306fcee4304977c7a4089d556453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_12ca85ac8e926ea952c0d6fd878450b444ec5e4734c37c52a96e8cd4ae05054b->leave($__internal_12ca85ac8e926ea952c0d6fd878450b444ec5e4734c37c52a96e8cd4ae05054b_prof);

        
        $__internal_cdc2a6ee3bec88a055f99f9ff5d0c57c7bfe306fcee4304977c7a4089d556453->leave($__internal_cdc2a6ee3bec88a055f99f9ff5d0c57c7bfe306fcee4304977c7a4089d556453_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_5e2a8deed72fa254edee4c8f5a11b03fbdb99f6d2ad2baf6f2e2afa9d933353b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e2a8deed72fa254edee4c8f5a11b03fbdb99f6d2ad2baf6f2e2afa9d933353b->enter($__internal_5e2a8deed72fa254edee4c8f5a11b03fbdb99f6d2ad2baf6f2e2afa9d933353b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f3124bb29abc48670f180614378213da9746d527a2ed9d6f014fa9d16d6da927 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3124bb29abc48670f180614378213da9746d527a2ed9d6f014fa9d16d6da927->enter($__internal_f3124bb29abc48670f180614378213da9746d527a2ed9d6f014fa9d16d6da927_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_f3124bb29abc48670f180614378213da9746d527a2ed9d6f014fa9d16d6da927->leave($__internal_f3124bb29abc48670f180614378213da9746d527a2ed9d6f014fa9d16d6da927_prof);

        
        $__internal_5e2a8deed72fa254edee4c8f5a11b03fbdb99f6d2ad2baf6f2e2afa9d933353b->leave($__internal_5e2a8deed72fa254edee4c8f5a11b03fbdb99f6d2ad2baf6f2e2afa9d933353b_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
