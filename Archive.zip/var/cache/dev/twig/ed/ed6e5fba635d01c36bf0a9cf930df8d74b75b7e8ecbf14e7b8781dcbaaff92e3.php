<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_70f9386e175b997e054a45a3d6b0e774218f345f71522730326007340b9626c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82c957e80fae920f34d06d3ee463bed1ad1662e3a5bebd061713ef01135a215c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82c957e80fae920f34d06d3ee463bed1ad1662e3a5bebd061713ef01135a215c->enter($__internal_82c957e80fae920f34d06d3ee463bed1ad1662e3a5bebd061713ef01135a215c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_9d00ebb7bab66fb2f0dd1068004f2c7c296e585f65d80fd7b35db1bd1b9d7d8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d00ebb7bab66fb2f0dd1068004f2c7c296e585f65d80fd7b35db1bd1b9d7d8c->enter($__internal_9d00ebb7bab66fb2f0dd1068004f2c7c296e585f65d80fd7b35db1bd1b9d7d8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_82c957e80fae920f34d06d3ee463bed1ad1662e3a5bebd061713ef01135a215c->leave($__internal_82c957e80fae920f34d06d3ee463bed1ad1662e3a5bebd061713ef01135a215c_prof);

        
        $__internal_9d00ebb7bab66fb2f0dd1068004f2c7c296e585f65d80fd7b35db1bd1b9d7d8c->leave($__internal_9d00ebb7bab66fb2f0dd1068004f2c7c296e585f65d80fd7b35db1bd1b9d7d8c_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_10e4bc8690b6b2246773630ef3c60b4ed959ee0172cca00d2e65d0ebd62a561d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10e4bc8690b6b2246773630ef3c60b4ed959ee0172cca00d2e65d0ebd62a561d->enter($__internal_10e4bc8690b6b2246773630ef3c60b4ed959ee0172cca00d2e65d0ebd62a561d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_05857a2092d48e5a8ea793a01f095408a986323b4d404bcada990ff41ef9593b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05857a2092d48e5a8ea793a01f095408a986323b4d404bcada990ff41ef9593b->enter($__internal_05857a2092d48e5a8ea793a01f095408a986323b4d404bcada990ff41ef9593b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_05857a2092d48e5a8ea793a01f095408a986323b4d404bcada990ff41ef9593b->leave($__internal_05857a2092d48e5a8ea793a01f095408a986323b4d404bcada990ff41ef9593b_prof);

        
        $__internal_10e4bc8690b6b2246773630ef3c60b4ed959ee0172cca00d2e65d0ebd62a561d->leave($__internal_10e4bc8690b6b2246773630ef3c60b4ed959ee0172cca00d2e65d0ebd62a561d_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_0816ddc93c6c1a32249e326da6be9e9f13749b6ea13d7abe44a633b80ac0e38b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0816ddc93c6c1a32249e326da6be9e9f13749b6ea13d7abe44a633b80ac0e38b->enter($__internal_0816ddc93c6c1a32249e326da6be9e9f13749b6ea13d7abe44a633b80ac0e38b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d8f5321faa6fd5f636ca842b7f61ec65360fd1df389a5e1304d70fe3e20c55bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8f5321faa6fd5f636ca842b7f61ec65360fd1df389a5e1304d70fe3e20c55bd->enter($__internal_d8f5321faa6fd5f636ca842b7f61ec65360fd1df389a5e1304d70fe3e20c55bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_d8f5321faa6fd5f636ca842b7f61ec65360fd1df389a5e1304d70fe3e20c55bd->leave($__internal_d8f5321faa6fd5f636ca842b7f61ec65360fd1df389a5e1304d70fe3e20c55bd_prof);

        
        $__internal_0816ddc93c6c1a32249e326da6be9e9f13749b6ea13d7abe44a633b80ac0e38b->leave($__internal_0816ddc93c6c1a32249e326da6be9e9f13749b6ea13d7abe44a633b80ac0e38b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_80765a50db79e66fc6b3bd1b55a2ef916145b2867d4130dc371b6f2a4a615288 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_80765a50db79e66fc6b3bd1b55a2ef916145b2867d4130dc371b6f2a4a615288->enter($__internal_80765a50db79e66fc6b3bd1b55a2ef916145b2867d4130dc371b6f2a4a615288_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_b6b236656f16c0b8dc18bfe380e4bade20f2d753c6da70b8b98623117beaf77c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6b236656f16c0b8dc18bfe380e4bade20f2d753c6da70b8b98623117beaf77c->enter($__internal_b6b236656f16c0b8dc18bfe380e4bade20f2d753c6da70b8b98623117beaf77c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_b6b236656f16c0b8dc18bfe380e4bade20f2d753c6da70b8b98623117beaf77c->leave($__internal_b6b236656f16c0b8dc18bfe380e4bade20f2d753c6da70b8b98623117beaf77c_prof);

        
        $__internal_80765a50db79e66fc6b3bd1b55a2ef916145b2867d4130dc371b6f2a4a615288->leave($__internal_80765a50db79e66fc6b3bd1b55a2ef916145b2867d4130dc371b6f2a4a615288_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
