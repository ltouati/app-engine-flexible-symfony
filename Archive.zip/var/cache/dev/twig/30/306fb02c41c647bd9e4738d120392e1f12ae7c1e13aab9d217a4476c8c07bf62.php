<?php

/* TwigBundle:Exception:error.html.twig */
class __TwigTemplate_6b201ceec3924bddd898d0e50fe4965fe8bbf34da97889036dca82221470201c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a45db6cd0646e439c6c5e46de488afff8466e350e4b0ab9849baff4df1a1e4ca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a45db6cd0646e439c6c5e46de488afff8466e350e4b0ab9849baff4df1a1e4ca->enter($__internal_a45db6cd0646e439c6c5e46de488afff8466e350e4b0ab9849baff4df1a1e4ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.html.twig"));

        $__internal_c0b2d226d701a9d1f2e37ba8f9e49b854bc6a25146b34b0fa25c1baa12342cc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0b2d226d701a9d1f2e37ba8f9e49b854bc6a25146b34b0fa25c1baa12342cc9->enter($__internal_c0b2d226d701a9d1f2e37ba8f9e49b854bc6a25146b34b0fa25c1baa12342cc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a45db6cd0646e439c6c5e46de488afff8466e350e4b0ab9849baff4df1a1e4ca->leave($__internal_a45db6cd0646e439c6c5e46de488afff8466e350e4b0ab9849baff4df1a1e4ca_prof);

        
        $__internal_c0b2d226d701a9d1f2e37ba8f9e49b854bc6a25146b34b0fa25c1baa12342cc9->leave($__internal_c0b2d226d701a9d1f2e37ba8f9e49b854bc6a25146b34b0fa25c1baa12342cc9_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_d0292604f3c2fcc26c105ce368204c28dd4d762acda9c4fda957b4b8bdece592 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d0292604f3c2fcc26c105ce368204c28dd4d762acda9c4fda957b4b8bdece592->enter($__internal_d0292604f3c2fcc26c105ce368204c28dd4d762acda9c4fda957b4b8bdece592_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_24f046d51644fbbb6f3240a3d01f5cf4d7a945605c4cef8a8c28356327b28f64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24f046d51644fbbb6f3240a3d01f5cf4d7a945605c4cef8a8c28356327b28f64->enter($__internal_24f046d51644fbbb6f3240a3d01f5cf4d7a945605c4cef8a8c28356327b28f64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_24f046d51644fbbb6f3240a3d01f5cf4d7a945605c4cef8a8c28356327b28f64->leave($__internal_24f046d51644fbbb6f3240a3d01f5cf4d7a945605c4cef8a8c28356327b28f64_prof);

        
        $__internal_d0292604f3c2fcc26c105ce368204c28dd4d762acda9c4fda957b4b8bdece592->leave($__internal_d0292604f3c2fcc26c105ce368204c28dd4d762acda9c4fda957b4b8bdece592_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_16be9e1875bc3a683c7ba2492e925630a1ed44c87b1287df8cc8633b000b147e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16be9e1875bc3a683c7ba2492e925630a1ed44c87b1287df8cc8633b000b147e->enter($__internal_16be9e1875bc3a683c7ba2492e925630a1ed44c87b1287df8cc8633b000b147e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_53ac7397b31652c6c8e040cfe8a29bb07732167bb4ac72f5a1196ada4d7fa13f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53ac7397b31652c6c8e040cfe8a29bb07732167bb4ac72f5a1196ada4d7fa13f->enter($__internal_53ac7397b31652c6c8e040cfe8a29bb07732167bb4ac72f5a1196ada4d7fa13f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")))), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.description", array("%status_code%" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")))), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.suggestion", array("%url%" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index")));
        echo "
    </p>
";
        
        $__internal_53ac7397b31652c6c8e040cfe8a29bb07732167bb4ac72f5a1196ada4d7fa13f->leave($__internal_53ac7397b31652c6c8e040cfe8a29bb07732167bb4ac72f5a1196ada4d7fa13f_prof);

        
        $__internal_16be9e1875bc3a683c7ba2492e925630a1ed44c87b1287df8cc8633b000b147e->leave($__internal_16be9e1875bc3a683c7ba2492e925630a1ed44c87b1287df8cc8633b000b147e_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_079bb2175bf47960aa73de57137abfe52257d09b70171fc0eecdf066ce63a9b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_079bb2175bf47960aa73de57137abfe52257d09b70171fc0eecdf066ce63a9b1->enter($__internal_079bb2175bf47960aa73de57137abfe52257d09b70171fc0eecdf066ce63a9b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_7ff318889adaafe0438b38f4b9d2ff344042748cc96bbc0b05fa9f202ef34eb7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7ff318889adaafe0438b38f4b9d2ff344042748cc96bbc0b05fa9f202ef34eb7->enter($__internal_7ff318889adaafe0438b38f4b9d2ff344042748cc96bbc0b05fa9f202ef34eb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_7ff318889adaafe0438b38f4b9d2ff344042748cc96bbc0b05fa9f202ef34eb7->leave($__internal_7ff318889adaafe0438b38f4b9d2ff344042748cc96bbc0b05fa9f202ef34eb7_prof);

        
        $__internal_079bb2175bf47960aa73de57137abfe52257d09b70171fc0eecdf066ce63a9b1->leave($__internal_079bb2175bf47960aa73de57137abfe52257d09b70171fc0eecdf066ce63a9b1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render any error different from 403, 404 and 500.

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See https://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'http_error.name'|trans({ '%status_code%': status_code }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error.description'|trans({ '%status_code%': status_code }) }}
    </p>
    <p>
        {{ 'http_error.suggestion'|trans({ '%url%': path('blog_index') })|raw }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/TwigBundle/views/Exception/error.html.twig");
    }
}
