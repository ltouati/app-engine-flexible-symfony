<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_e576ca967d3be1624bf5511ff8daec2aaba36819da9e370f3f6cad92b6c4363d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c1fdf0182fb61aa0e9d1e6d671ab9be40369bdadbf2fd2cf95b6dfc7541940a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0c1fdf0182fb61aa0e9d1e6d671ab9be40369bdadbf2fd2cf95b6dfc7541940a->enter($__internal_0c1fdf0182fb61aa0e9d1e6d671ab9be40369bdadbf2fd2cf95b6dfc7541940a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_8a86b9c4066f63a4150cee49854994a2c49b71f189ca4dd97d41c98732f6b6b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a86b9c4066f63a4150cee49854994a2c49b71f189ca4dd97d41c98732f6b6b9->enter($__internal_8a86b9c4066f63a4150cee49854994a2c49b71f189ca4dd97d41c98732f6b6b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_0c1fdf0182fb61aa0e9d1e6d671ab9be40369bdadbf2fd2cf95b6dfc7541940a->leave($__internal_0c1fdf0182fb61aa0e9d1e6d671ab9be40369bdadbf2fd2cf95b6dfc7541940a_prof);

        
        $__internal_8a86b9c4066f63a4150cee49854994a2c49b71f189ca4dd97d41c98732f6b6b9->leave($__internal_8a86b9c4066f63a4150cee49854994a2c49b71f189ca4dd97d41c98732f6b6b9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rows.html.php");
    }
}
