<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_d2a19dd9f431887b49bf7771c40f7099a8e8ac4616c4947aa9789cb879c5ac30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90845b5438f08b9d738bddbbd7e932f6e241a7a47822a91b053682f94fb5fb5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_90845b5438f08b9d738bddbbd7e932f6e241a7a47822a91b053682f94fb5fb5c->enter($__internal_90845b5438f08b9d738bddbbd7e932f6e241a7a47822a91b053682f94fb5fb5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_a884362c8da1ced6bf382a27cfcc0877d7b69a787a9dbc2e05cbc04ae5809630 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a884362c8da1ced6bf382a27cfcc0877d7b69a787a9dbc2e05cbc04ae5809630->enter($__internal_a884362c8da1ced6bf382a27cfcc0877d7b69a787a9dbc2e05cbc04ae5809630_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_90845b5438f08b9d738bddbbd7e932f6e241a7a47822a91b053682f94fb5fb5c->leave($__internal_90845b5438f08b9d738bddbbd7e932f6e241a7a47822a91b053682f94fb5fb5c_prof);

        
        $__internal_a884362c8da1ced6bf382a27cfcc0877d7b69a787a9dbc2e05cbc04ae5809630->leave($__internal_a884362c8da1ced6bf382a27cfcc0877d7b69a787a9dbc2e05cbc04ae5809630_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.css.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
