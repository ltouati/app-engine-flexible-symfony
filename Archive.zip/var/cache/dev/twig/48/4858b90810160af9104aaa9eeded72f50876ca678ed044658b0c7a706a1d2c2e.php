<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_2dbfc5da9414b24721b89225f6530bf2a40025cafd2bca560a14de7b6a8919db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_385341a1e76c33b45a08a66ef17b51f610de09d46ab3220baf3f5d0db2095228 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_385341a1e76c33b45a08a66ef17b51f610de09d46ab3220baf3f5d0db2095228->enter($__internal_385341a1e76c33b45a08a66ef17b51f610de09d46ab3220baf3f5d0db2095228_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        $__internal_2f3d806c1a01db104cb5ce49a1cc7abc2eeea969dff4f5ff52ef6ca2672ad01f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f3d806c1a01db104cb5ce49a1cc7abc2eeea969dff4f5ff52ef6ca2672ad01f->enter($__internal_2f3d806c1a01db104cb5ce49a1cc7abc2eeea969dff4f5ff52ef6ca2672ad01f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_385341a1e76c33b45a08a66ef17b51f610de09d46ab3220baf3f5d0db2095228->leave($__internal_385341a1e76c33b45a08a66ef17b51f610de09d46ab3220baf3f5d0db2095228_prof);

        
        $__internal_2f3d806c1a01db104cb5ce49a1cc7abc2eeea969dff4f5ff52ef6ca2672ad01f->leave($__internal_2f3d806c1a01db104cb5ce49a1cc7abc2eeea969dff4f5ff52ef6ca2672ad01f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
", "@Framework/Form/range_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/range_widget.html.php");
    }
}
