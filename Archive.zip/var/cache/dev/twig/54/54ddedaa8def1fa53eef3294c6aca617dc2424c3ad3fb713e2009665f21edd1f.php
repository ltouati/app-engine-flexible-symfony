<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_8c7e36779551da71b9be94d02d6eaca0081811bd9cfd62570bc9a02286344623 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb743af13072b6cdc427a73c21775059657e5840e4523b5b7573ec4eb3b7e781 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb743af13072b6cdc427a73c21775059657e5840e4523b5b7573ec4eb3b7e781->enter($__internal_cb743af13072b6cdc427a73c21775059657e5840e4523b5b7573ec4eb3b7e781_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_a48394a56ec67a1aa55d304f7225e6cad5dc4ea5285d304a177da2ef9331169f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a48394a56ec67a1aa55d304f7225e6cad5dc4ea5285d304a177da2ef9331169f->enter($__internal_a48394a56ec67a1aa55d304f7225e6cad5dc4ea5285d304a177da2ef9331169f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_cb743af13072b6cdc427a73c21775059657e5840e4523b5b7573ec4eb3b7e781->leave($__internal_cb743af13072b6cdc427a73c21775059657e5840e4523b5b7573ec4eb3b7e781_prof);

        
        $__internal_a48394a56ec67a1aa55d304f7225e6cad5dc4ea5285d304a177da2ef9331169f->leave($__internal_a48394a56ec67a1aa55d304f7225e6cad5dc4ea5285d304a177da2ef9331169f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
