<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_3c880f8c91534f426bd47ae51f121f5f285808d50151a6827f7d844dc94b6f76 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57e43604fce94f2320b03f77b2cf9bf87eebc1f3963a82484a7b507edbb2f9ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_57e43604fce94f2320b03f77b2cf9bf87eebc1f3963a82484a7b507edbb2f9ab->enter($__internal_57e43604fce94f2320b03f77b2cf9bf87eebc1f3963a82484a7b507edbb2f9ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_0f67acf7d7c8bfb971e39bfba807a619d81abd47b718ed332ed6cac1131a1cd1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f67acf7d7c8bfb971e39bfba807a619d81abd47b718ed332ed6cac1131a1cd1->enter($__internal_0f67acf7d7c8bfb971e39bfba807a619d81abd47b718ed332ed6cac1131a1cd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_57e43604fce94f2320b03f77b2cf9bf87eebc1f3963a82484a7b507edbb2f9ab->leave($__internal_57e43604fce94f2320b03f77b2cf9bf87eebc1f3963a82484a7b507edbb2f9ab_prof);

        
        $__internal_0f67acf7d7c8bfb971e39bfba807a619d81abd47b718ed332ed6cac1131a1cd1->leave($__internal_0f67acf7d7c8bfb971e39bfba807a619d81abd47b718ed332ed6cac1131a1cd1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
