<?php

/* TwigBundle:Exception:error403.html.twig */
class __TwigTemplate_6aae9950e2994c930a2a254ea3584a9d5b7b1b80cd53a1e8f48cce1ca8eab8a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error403.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e0b85f1188356a2188687a0d07cae7531d1af6182238af1b078a27ecac75a6ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0b85f1188356a2188687a0d07cae7531d1af6182238af1b078a27ecac75a6ec->enter($__internal_e0b85f1188356a2188687a0d07cae7531d1af6182238af1b078a27ecac75a6ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error403.html.twig"));

        $__internal_cfe00e3ac4cb492969ec8870ad8ad5c6743986f3bddac234bbba7d631091ae44 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfe00e3ac4cb492969ec8870ad8ad5c6743986f3bddac234bbba7d631091ae44->enter($__internal_cfe00e3ac4cb492969ec8870ad8ad5c6743986f3bddac234bbba7d631091ae44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e0b85f1188356a2188687a0d07cae7531d1af6182238af1b078a27ecac75a6ec->leave($__internal_e0b85f1188356a2188687a0d07cae7531d1af6182238af1b078a27ecac75a6ec_prof);

        
        $__internal_cfe00e3ac4cb492969ec8870ad8ad5c6743986f3bddac234bbba7d631091ae44->leave($__internal_cfe00e3ac4cb492969ec8870ad8ad5c6743986f3bddac234bbba7d631091ae44_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_feb49fc4d73970460458b1b1bb352618c4b4ee453c9d6c1cd307cee25e8a9850 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_feb49fc4d73970460458b1b1bb352618c4b4ee453c9d6c1cd307cee25e8a9850->enter($__internal_feb49fc4d73970460458b1b1bb352618c4b4ee453c9d6c1cd307cee25e8a9850_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_06ccefc4c71c2781883b44af87d560f459b8d45a1ac9ca321b374e598e76d72a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06ccefc4c71c2781883b44af87d560f459b8d45a1ac9ca321b374e598e76d72a->enter($__internal_06ccefc4c71c2781883b44af87d560f459b8d45a1ac9ca321b374e598e76d72a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_06ccefc4c71c2781883b44af87d560f459b8d45a1ac9ca321b374e598e76d72a->leave($__internal_06ccefc4c71c2781883b44af87d560f459b8d45a1ac9ca321b374e598e76d72a_prof);

        
        $__internal_feb49fc4d73970460458b1b1bb352618c4b4ee453c9d6c1cd307cee25e8a9850->leave($__internal_feb49fc4d73970460458b1b1bb352618c4b4ee453c9d6c1cd307cee25e8a9850_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_d6f5d5ad461073beefca0080ca6534a7e8574ffc8b87d8cfd63903fffdffe74e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6f5d5ad461073beefca0080ca6534a7e8574ffc8b87d8cfd63903fffdffe74e->enter($__internal_d6f5d5ad461073beefca0080ca6534a7e8574ffc8b87d8cfd63903fffdffe74e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_75bbaeb0d1132a5e2192526fad1e948e686e59095c4e8ac7cec043a42edcd63a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75bbaeb0d1132a5e2192526fad1e948e686e59095c4e8ac7cec043a42edcd63a->enter($__internal_75bbaeb0d1132a5e2192526fad1e948e686e59095c4e8ac7cec043a42edcd63a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\"><i class=\"fa fa-unlock-alt\" aria-hidden=\"true\"></i> ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => 403)), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_403.description"), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_403.suggestion"), "html", null, true);
        echo "
    </p>
";
        
        $__internal_75bbaeb0d1132a5e2192526fad1e948e686e59095c4e8ac7cec043a42edcd63a->leave($__internal_75bbaeb0d1132a5e2192526fad1e948e686e59095c4e8ac7cec043a42edcd63a_prof);

        
        $__internal_d6f5d5ad461073beefca0080ca6534a7e8574ffc8b87d8cfd63903fffdffe74e->leave($__internal_d6f5d5ad461073beefca0080ca6534a7e8574ffc8b87d8cfd63903fffdffe74e_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_4fac736c07d65fe0696f5659fbf093bfd7fb426e58679cfd35199d01d91fc5db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4fac736c07d65fe0696f5659fbf093bfd7fb426e58679cfd35199d01d91fc5db->enter($__internal_4fac736c07d65fe0696f5659fbf093bfd7fb426e58679cfd35199d01d91fc5db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_f9816de8d7b4467294ecbaf9c3d6884879a66d6a6b25140f3e20571892fb1da1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9816de8d7b4467294ecbaf9c3d6884879a66d6a6b25140f3e20571892fb1da1->enter($__internal_f9816de8d7b4467294ecbaf9c3d6884879a66d6a6b25140f3e20571892fb1da1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_f9816de8d7b4467294ecbaf9c3d6884879a66d6a6b25140f3e20571892fb1da1->leave($__internal_f9816de8d7b4467294ecbaf9c3d6884879a66d6a6b25140f3e20571892fb1da1_prof);

        
        $__internal_4fac736c07d65fe0696f5659fbf093bfd7fb426e58679cfd35199d01d91fc5db->leave($__internal_4fac736c07d65fe0696f5659fbf093bfd7fb426e58679cfd35199d01d91fc5db_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render errors of type HTTP 403 (Forbidden)

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See https://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\"><i class=\"fa fa-unlock-alt\" aria-hidden=\"true\"></i> {{ 'http_error.name'|trans({ '%status_code%': 403 }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error_403.description'|trans }}
    </p>
    <p>
        {{ 'http_error_403.suggestion'|trans }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error403.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/TwigBundle/views/Exception/error403.html.twig");
    }
}
