<?php

/* base.html.twig */
class __TwigTemplate_a80407c7d5c2a497fac8b672fc0464e607742708bc51fb404991f5258c7f8d3f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3273f738a53be54889dbf51301937ec4a6ce48fe9e2bd3fa10ac0c4a0f0b0e07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3273f738a53be54889dbf51301937ec4a6ce48fe9e2bd3fa10ac0c4a0f0b0e07->enter($__internal_3273f738a53be54889dbf51301937ec4a6ce48fe9e2bd3fa10ac0c4a0f0b0e07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_0dc5e54240518c6b1a43ba2ae1cae79f9ce9f4c4f617e3c3ef322a321c77616a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0dc5e54240518c6b1a43ba2ae1cae79f9ce9f4c4f617e3c3ef322a321c77616a->enter($__internal_0dc5e54240518c6b1a43ba2ae1cae79f9ce9f4c4f617e3c3ef322a321c77616a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()), "html", null, true);
        echo "\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("rss.title"), "html", null, true);
        echo "\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 22
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>

    <body id=\"";
        // line 25
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

        ";
        // line 27
        $this->displayBlock('header', $context, $blocks);
        // line 90
        echo "
        <div class=\"container body-container\">
            ";
        // line 92
        $this->displayBlock('body', $context, $blocks);
        // line 111
        echo "        </div>

        ";
        // line 113
        $this->displayBlock('footer', $context, $blocks);
        // line 138
        echo "
        ";
        // line 139
        $this->displayBlock('javascripts', $context, $blocks);
        // line 148
        echo "
        ";
        // line 152
        echo "        <!-- Page rendered on ";
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, "now", "long", "long", null, "UTC"), "html", null, true);
        echo " -->
    </body>
</html>
";
        
        $__internal_3273f738a53be54889dbf51301937ec4a6ce48fe9e2bd3fa10ac0c4a0f0b0e07->leave($__internal_3273f738a53be54889dbf51301937ec4a6ce48fe9e2bd3fa10ac0c4a0f0b0e07_prof);

        
        $__internal_0dc5e54240518c6b1a43ba2ae1cae79f9ce9f4c4f617e3c3ef322a321c77616a->leave($__internal_0dc5e54240518c6b1a43ba2ae1cae79f9ce9f4c4f617e3c3ef322a321c77616a_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_bf9e293ae0fc78feb34b192230932e53263a3d6ea3869b8e11b1b573e537b0cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf9e293ae0fc78feb34b192230932e53263a3d6ea3869b8e11b1b573e537b0cc->enter($__internal_bf9e293ae0fc78feb34b192230932e53263a3d6ea3869b8e11b1b573e537b0cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_12d960a715d144bf1a816ffbf036e6d2e61f423ac41638091d89dfdcfcbcefe5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12d960a715d144bf1a816ffbf036e6d2e61f423ac41638091d89dfdcfcbcefe5->enter($__internal_12d960a715d144bf1a816ffbf036e6d2e61f423ac41638091d89dfdcfcbcefe5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symfony Demo application";
        
        $__internal_12d960a715d144bf1a816ffbf036e6d2e61f423ac41638091d89dfdcfcbcefe5->leave($__internal_12d960a715d144bf1a816ffbf036e6d2e61f423ac41638091d89dfdcfcbcefe5_prof);

        
        $__internal_bf9e293ae0fc78feb34b192230932e53263a3d6ea3869b8e11b1b573e537b0cc->leave($__internal_bf9e293ae0fc78feb34b192230932e53263a3d6ea3869b8e11b1b573e537b0cc_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ce3b1683145dc46afa6bf04fc7e42ce956bb36b9cebb768c67d5d58d0689a423 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce3b1683145dc46afa6bf04fc7e42ce956bb36b9cebb768c67d5d58d0689a423->enter($__internal_ce3b1683145dc46afa6bf04fc7e42ce956bb36b9cebb768c67d5d58d0689a423_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_95479e26e33906b86dcff66574beeaa8d1ca15ec4b862b9477cebbdf29cd9ccf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95479e26e33906b86dcff66574beeaa8d1ca15ec4b862b9477cebbdf29cd9ccf->enter($__internal_95479e26e33906b86dcff66574beeaa8d1ca15ec4b862b9477cebbdf29cd9ccf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 14
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-flatly-3.3.7.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-awesome-4.6.3.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-lato.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/highlight-solarized-light.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-tagsinput.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_95479e26e33906b86dcff66574beeaa8d1ca15ec4b862b9477cebbdf29cd9ccf->leave($__internal_95479e26e33906b86dcff66574beeaa8d1ca15ec4b862b9477cebbdf29cd9ccf_prof);

        
        $__internal_ce3b1683145dc46afa6bf04fc7e42ce956bb36b9cebb768c67d5d58d0689a423->leave($__internal_ce3b1683145dc46afa6bf04fc7e42ce956bb36b9cebb768c67d5d58d0689a423_prof);

    }

    // line 25
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_ebc563a1431f86dfd08771faee066f5d804df239178b9f027fb43cf83ad9a2a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ebc563a1431f86dfd08771faee066f5d804df239178b9f027fb43cf83ad9a2a9->enter($__internal_ebc563a1431f86dfd08771faee066f5d804df239178b9f027fb43cf83ad9a2a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_53ed4d85268b2d0145f2dc6011fe8d2220aa48d748188ed138cca41ecb92a17d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53ed4d85268b2d0145f2dc6011fe8d2220aa48d748188ed138cca41ecb92a17d->enter($__internal_53ed4d85268b2d0145f2dc6011fe8d2220aa48d748188ed138cca41ecb92a17d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_53ed4d85268b2d0145f2dc6011fe8d2220aa48d748188ed138cca41ecb92a17d->leave($__internal_53ed4d85268b2d0145f2dc6011fe8d2220aa48d748188ed138cca41ecb92a17d_prof);

        
        $__internal_ebc563a1431f86dfd08771faee066f5d804df239178b9f027fb43cf83ad9a2a9->leave($__internal_ebc563a1431f86dfd08771faee066f5d804df239178b9f027fb43cf83ad9a2a9_prof);

    }

    // line 27
    public function block_header($context, array $blocks = array())
    {
        $__internal_68c0fe10072e28a52986c535d8194a6fadb57e505e5963cc15bbfc5bbd44acec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68c0fe10072e28a52986c535d8194a6fadb57e505e5963cc15bbfc5bbd44acec->enter($__internal_68c0fe10072e28a52986c535d8194a6fadb57e505e5963cc15bbfc5bbd44acec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_26424c88257e4c0d13f80b7b50b7e4742dc07d7d2169820ec138eb6b7ce59edf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26424c88257e4c0d13f80b7b50b7e4742dc07d7d2169820ec138eb6b7ce59edf->enter($__internal_26424c88257e4c0d13f80b7b50b7e4742dc07d7d2169820ec138eb6b7ce59edf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 28
        echo "            <header>
                <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
                    <div class=\"container\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">
                                Symfony Demo
                            </a>

                            <button type=\"button\" class=\"navbar-toggle\"
                                    data-toggle=\"collapse\"
                                    data-target=\".navbar-collapse\">
                                <span class=\"sr-only\">";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.toggle_nav"), "html", null, true);
        echo "</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav navbar-right\">

                                ";
        // line 48
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 63
        echo "
                                ";
        // line 64
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 65
            echo "                                    <li>
                                        <a href=\"";
            // line 66
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">
                                            <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> ";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.logout"), "html", null, true);
            echo "
                                        </a>
                                    </li>
                                ";
        }
        // line 71
        echo "
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" id=\"locales\">
                                        <i class=\"fa fa-globe\" aria-hidden=\"true\"></i>
                                        <span class=\"caret\"></span>
                                        <span class=\"sr-only\">";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.choose_language"), "html", null, true);
        echo "</span>
                                    </a>
                                    <ul class=\"dropdown-menu locales\" role=\"menu\" aria-labelledby=\"locales\">
                                        ";
        // line 79
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('AppBundle\Twig\AppExtension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 80
            echo "                                            <li ";
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "aria-checked=\"true\" class=\"active\"";
            } else {
                echo "aria-checked=\"false\"";
            }
            echo " role=\"menuitem\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a></li>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        ";
        
        $__internal_26424c88257e4c0d13f80b7b50b7e4742dc07d7d2169820ec138eb6b7ce59edf->leave($__internal_26424c88257e4c0d13f80b7b50b7e4742dc07d7d2169820ec138eb6b7ce59edf_prof);

        
        $__internal_68c0fe10072e28a52986c535d8194a6fadb57e505e5963cc15bbfc5bbd44acec->leave($__internal_68c0fe10072e28a52986c535d8194a6fadb57e505e5963cc15bbfc5bbd44acec_prof);

    }

    // line 48
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_1db6dc722b102e3cab337ecda6ebd1ba194e2339862827843ef81fe73914af33 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1db6dc722b102e3cab337ecda6ebd1ba194e2339862827843ef81fe73914af33->enter($__internal_1db6dc722b102e3cab337ecda6ebd1ba194e2339862827843ef81fe73914af33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_d1075c9b2d27e32e8b381c1ce6a734f1e4c1e262de04f7bcf28934ccb9954116 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1075c9b2d27e32e8b381c1ce6a734f1e4c1e262de04f7bcf28934ccb9954116->enter($__internal_d1075c9b2d27e32e8b381c1ce6a734f1e4c1e262de04f7bcf28934ccb9954116_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 49
        echo "                                    <li>
                                        <a href=\"";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
                                            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> ";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.homepage"), "html", null, true);
        echo "
                                        </a>
                                    </li>

                                    ";
        // line 55
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 56
            echo "                                        <li>
                                            <a href=\"";
            // line 57
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
            echo "\">
                                                <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
            // line 58
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.admin"), "html", null, true);
            echo "
                                            </a>
                                        </li>
                                    ";
        }
        // line 62
        echo "                                ";
        
        $__internal_d1075c9b2d27e32e8b381c1ce6a734f1e4c1e262de04f7bcf28934ccb9954116->leave($__internal_d1075c9b2d27e32e8b381c1ce6a734f1e4c1e262de04f7bcf28934ccb9954116_prof);

        
        $__internal_1db6dc722b102e3cab337ecda6ebd1ba194e2339862827843ef81fe73914af33->leave($__internal_1db6dc722b102e3cab337ecda6ebd1ba194e2339862827843ef81fe73914af33_prof);

    }

    // line 92
    public function block_body($context, array $blocks = array())
    {
        $__internal_eb9aff527fad004493fdd5b65176a21936b564ea599759abca5da4f56c08ea65 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb9aff527fad004493fdd5b65176a21936b564ea599759abca5da4f56c08ea65->enter($__internal_eb9aff527fad004493fdd5b65176a21936b564ea599759abca5da4f56c08ea65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cc27871e62aaa136a42cb5aea9da14abdd1d65ec5c7510de54b84d826126a846 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc27871e62aaa136a42cb5aea9da14abdd1d65ec5c7510de54b84d826126a846->enter($__internal_cc27871e62aaa136a42cb5aea9da14abdd1d65ec5c7510de54b84d826126a846_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 93
        echo "                <div class=\"row\">
                    <div id=\"main\" class=\"col-sm-9\">
                        ";
        // line 95
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "

                        ";
        // line 97
        $this->displayBlock('main', $context, $blocks);
        // line 98
        echo "                    </div>

                    <div id=\"sidebar\" class=\"col-sm-3\">
                        ";
        // line 101
        $this->displayBlock('sidebar', $context, $blocks);
        // line 108
        echo "                    </div>
                </div>
            ";
        
        $__internal_cc27871e62aaa136a42cb5aea9da14abdd1d65ec5c7510de54b84d826126a846->leave($__internal_cc27871e62aaa136a42cb5aea9da14abdd1d65ec5c7510de54b84d826126a846_prof);

        
        $__internal_eb9aff527fad004493fdd5b65176a21936b564ea599759abca5da4f56c08ea65->leave($__internal_eb9aff527fad004493fdd5b65176a21936b564ea599759abca5da4f56c08ea65_prof);

    }

    // line 97
    public function block_main($context, array $blocks = array())
    {
        $__internal_007013f4aaaf2370ea582359175996f5ab2740c3811787182facd299dfe13431 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_007013f4aaaf2370ea582359175996f5ab2740c3811787182facd299dfe13431->enter($__internal_007013f4aaaf2370ea582359175996f5ab2740c3811787182facd299dfe13431_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_0dd3a0ecaa5bbbd8f4300eb2d4629cc0e6d60ec43382d18c27b4d20b4e29eac5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0dd3a0ecaa5bbbd8f4300eb2d4629cc0e6d60ec43382d18c27b4d20b4e29eac5->enter($__internal_0dd3a0ecaa5bbbd8f4300eb2d4629cc0e6d60ec43382d18c27b4d20b4e29eac5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_0dd3a0ecaa5bbbd8f4300eb2d4629cc0e6d60ec43382d18c27b4d20b4e29eac5->leave($__internal_0dd3a0ecaa5bbbd8f4300eb2d4629cc0e6d60ec43382d18c27b4d20b4e29eac5_prof);

        
        $__internal_007013f4aaaf2370ea582359175996f5ab2740c3811787182facd299dfe13431->leave($__internal_007013f4aaaf2370ea582359175996f5ab2740c3811787182facd299dfe13431_prof);

    }

    // line 101
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_dcfa2f5fde1c9b047c14b042974f9583f7eb39b417128d0551df973c5106f723 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dcfa2f5fde1c9b047c14b042974f9583f7eb39b417128d0551df973c5106f723->enter($__internal_dcfa2f5fde1c9b047c14b042974f9583f7eb39b417128d0551df973c5106f723_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_d763c760cf363f05426a986bc21e1013a39f68d795adef9e4a3f8139a7996c01 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d763c760cf363f05426a986bc21e1013a39f68d795adef9e4a3f8139a7996c01->enter($__internal_d763c760cf363f05426a986bc21e1013a39f68d795adef9e4a3f8139a7996c01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 102
        echo "                            ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragmentStrategy("esi", Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("FrameworkBundle:Template:template", array("template" => "blog/about.html.twig", "sharedAge" => 600, "_locale" => $this->getAttribute($this->getAttribute(        // line 105
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()))));
        // line 106
        echo "
                        ";
        
        $__internal_d763c760cf363f05426a986bc21e1013a39f68d795adef9e4a3f8139a7996c01->leave($__internal_d763c760cf363f05426a986bc21e1013a39f68d795adef9e4a3f8139a7996c01_prof);

        
        $__internal_dcfa2f5fde1c9b047c14b042974f9583f7eb39b417128d0551df973c5106f723->leave($__internal_dcfa2f5fde1c9b047c14b042974f9583f7eb39b417128d0551df973c5106f723_prof);

    }

    // line 113
    public function block_footer($context, array $blocks = array())
    {
        $__internal_74a6f1603da214667a272415cacff1daf5464459f08118fdae470e8dc520939f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74a6f1603da214667a272415cacff1daf5464459f08118fdae470e8dc520939f->enter($__internal_74a6f1603da214667a272415cacff1daf5464459f08118fdae470e8dc520939f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_37d5fccc75a363c5fd543107710f777c8358c8aebb08b60c01532369c023af1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37d5fccc75a363c5fd543107710f777c8358c8aebb08b60c01532369c023af1e->enter($__internal_37d5fccc75a363c5fd543107710f777c8358c8aebb08b60c01532369c023af1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 114
        echo "            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\">
                            <p>&copy; ";
        // line 118
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " - The Symfony Project</p>
                            <p>";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("mit_license"), "html", null, true);
        echo "</p>
                        </div>
                        <div id=\"footer-resources\" class=\"col-md-6\">
                            <p>
                                <a href=\"https://twitter.com/symfony\" title=\"Symfony Twitter\">
                                    <i class=\"fa fa-twitter\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://www.facebook.com/SensioLabs\" title=\"SensioLabs Facebook\">
                                    <i class=\"fa fa-facebook\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://symfony.com/blog/\" title=\"Symfony Blog\">
                                    <i class=\"fa fa-rss\" aria-hidden=\"true\"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        ";
        
        $__internal_37d5fccc75a363c5fd543107710f777c8358c8aebb08b60c01532369c023af1e->leave($__internal_37d5fccc75a363c5fd543107710f777c8358c8aebb08b60c01532369c023af1e_prof);

        
        $__internal_74a6f1603da214667a272415cacff1daf5464459f08118fdae470e8dc520939f->leave($__internal_74a6f1603da214667a272415cacff1daf5464459f08118fdae470e8dc520939f_prof);

    }

    // line 139
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c97fef82ae431516f614603ade56a35b4a0eacda83c9cf66871df5d9af8d64fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c97fef82ae431516f614603ade56a35b4a0eacda83c9cf66871df5d9af8d64fa->enter($__internal_c97fef82ae431516f614603ade56a35b4a0eacda83c9cf66871df5d9af8d64fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_c7b0a4ef554c86a405a628ad32111092f585726f8e9a33e6ef8e6b461994a94a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7b0a4ef554c86a405a628ad32111092f585726f8e9a33e6ef8e6b461994a94a->enter($__internal_c7b0a4ef554c86a405a628ad32111092f585726f8e9a33e6ef8e6b461994a94a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 140
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 141
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 142
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-3.3.7.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/highlight.pack.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 145
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-tagsinput.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 146
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_c7b0a4ef554c86a405a628ad32111092f585726f8e9a33e6ef8e6b461994a94a->leave($__internal_c7b0a4ef554c86a405a628ad32111092f585726f8e9a33e6ef8e6b461994a94a_prof);

        
        $__internal_c97fef82ae431516f614603ade56a35b4a0eacda83c9cf66871df5d9af8d64fa->leave($__internal_c97fef82ae431516f614603ade56a35b4a0eacda83c9cf66871df5d9af8d64fa_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  507 => 146,  503 => 145,  499 => 144,  495 => 143,  491 => 142,  487 => 141,  482 => 140,  473 => 139,  444 => 119,  440 => 118,  434 => 114,  425 => 113,  414 => 106,  412 => 105,  410 => 102,  401 => 101,  384 => 97,  372 => 108,  370 => 101,  365 => 98,  363 => 97,  358 => 95,  354 => 93,  345 => 92,  335 => 62,  328 => 58,  324 => 57,  321 => 56,  319 => 55,  312 => 51,  308 => 50,  305 => 49,  296 => 48,  279 => 82,  262 => 80,  258 => 79,  252 => 76,  245 => 71,  238 => 67,  234 => 66,  231 => 65,  229 => 64,  226 => 63,  224 => 48,  212 => 39,  202 => 32,  196 => 28,  187 => 27,  170 => 25,  158 => 20,  154 => 19,  150 => 18,  146 => 17,  142 => 16,  138 => 15,  133 => 14,  124 => 13,  106 => 11,  91 => 152,  88 => 148,  86 => 139,  83 => 138,  81 => 113,  77 => 111,  75 => 92,  71 => 90,  69 => 27,  64 => 25,  57 => 22,  55 => 13,  49 => 12,  45 => 11,  38 => 7,  35 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See https://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"{{ app.request.locale }}\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>{% block title %}Symfony Demo application{% endblock %}</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"{{ 'rss.title'|trans }}\" href=\"{{ path('blog_rss') }}\">
        {% block stylesheets %}
            <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-flatly-3.3.7.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/font-awesome-4.6.3.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/font-lato.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/highlight-solarized-light.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-tagsinput.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/main.css') }}\">
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>

    <body id=\"{% block body_id %}{% endblock %}\">

        {% block header %}
            <header>
                <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
                    <div class=\"container\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">
                                Symfony Demo
                            </a>

                            <button type=\"button\" class=\"navbar-toggle\"
                                    data-toggle=\"collapse\"
                                    data-target=\".navbar-collapse\">
                                <span class=\"sr-only\">{{ 'menu.toggle_nav'|trans }}</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav navbar-right\">

                                {% block header_navigation_links %}
                                    <li>
                                        <a href=\"{{ path('blog_index') }}\">
                                            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> {{ 'menu.homepage'|trans }}
                                        </a>
                                    </li>

                                    {% if is_granted('ROLE_ADMIN') %}
                                        <li>
                                            <a href=\"{{ path('admin_post_index') }}\">
                                                <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'menu.admin'|trans }}
                                            </a>
                                        </li>
                                    {% endif %}
                                {% endblock %}

                                {% if app.user %}
                                    <li>
                                        <a href=\"{{ path('security_logout') }}\">
                                            <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> {{ 'menu.logout'|trans }}
                                        </a>
                                    </li>
                                {% endif %}

                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" id=\"locales\">
                                        <i class=\"fa fa-globe\" aria-hidden=\"true\"></i>
                                        <span class=\"caret\"></span>
                                        <span class=\"sr-only\">{{ 'menu.choose_language'|trans }}</span>
                                    </a>
                                    <ul class=\"dropdown-menu locales\" role=\"menu\" aria-labelledby=\"locales\">
                                        {% for locale in locales() %}
                                            <li {% if app.request.locale == locale.code %}aria-checked=\"true\" class=\"active\"{% else %}aria-checked=\"false\"{% endif %} role=\"menuitem\"><a href=\"{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({_locale: locale.code})) }}\">{{ locale.name|capitalize }}</a></li>
                                        {% endfor %}
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        {% endblock %}

        <div class=\"container body-container\">
            {% block body %}
                <div class=\"row\">
                    <div id=\"main\" class=\"col-sm-9\">
                        {{ include('default/_flash_messages.html.twig') }}

                        {% block main %}{% endblock %}
                    </div>

                    <div id=\"sidebar\" class=\"col-sm-3\">
                        {% block sidebar %}
                            {{ render_esi(controller('FrameworkBundle:Template:template', {
                                'template': 'blog/about.html.twig',
                                'sharedAge': 600,
                                '_locale': app.request.locale
                            })) }}
                        {% endblock %}
                    </div>
                </div>
            {% endblock %}
        </div>

        {% block footer %}
            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\">
                            <p>&copy; {{ 'now'|date('Y') }} - The Symfony Project</p>
                            <p>{{ 'mit_license'|trans }}</p>
                        </div>
                        <div id=\"footer-resources\" class=\"col-md-6\">
                            <p>
                                <a href=\"https://twitter.com/symfony\" title=\"Symfony Twitter\">
                                    <i class=\"fa fa-twitter\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://www.facebook.com/SensioLabs\" title=\"SensioLabs Facebook\">
                                    <i class=\"fa fa-facebook\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://symfony.com/blog/\" title=\"Symfony Blog\">
                                    <i class=\"fa fa-rss\" aria-hidden=\"true\"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        {% endblock %}

        {% block javascripts %}
            <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
            <script src=\"{{ asset('js/moment.min.js') }}\"></script>
            <script src=\"{{ asset('js/bootstrap-3.3.7.min.js') }}\"></script>
            <script src=\"{{ asset('js/highlight.pack.js') }}\"></script>
            <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
            <script src=\"{{ asset('js/bootstrap-tagsinput.min.js') }}\"></script>
            <script src=\"{{ asset('js/main.js') }}\"></script>
        {% endblock %}

        {# it's not mandatory to set the timezone in localizeddate(). This is done to
           avoid errors when the 'intl' PHP extension is not available and the application
           is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
        <!-- Page rendered on {{ 'now'|localizeddate('long', 'long', null, 'UTC') }} -->
    </body>
</html>
", "base.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/base.html.twig");
    }
}
