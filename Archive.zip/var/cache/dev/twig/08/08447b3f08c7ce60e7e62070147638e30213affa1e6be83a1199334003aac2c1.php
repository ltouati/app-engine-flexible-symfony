<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_ac6eee09125b1a7df4776dbac9bd99a18773b00bf5dde4d111df7be4ed0a7b0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_11ef377453a4cf38a5eec80aec9c2b3acef0432f4e2f522cbcb59ccd2bd883a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11ef377453a4cf38a5eec80aec9c2b3acef0432f4e2f522cbcb59ccd2bd883a8->enter($__internal_11ef377453a4cf38a5eec80aec9c2b3acef0432f4e2f522cbcb59ccd2bd883a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_3fb0effb45c99e37d1f302b1a4774cf9d5b03863e3f5b2f741476d293ab88d03 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fb0effb45c99e37d1f302b1a4774cf9d5b03863e3f5b2f741476d293ab88d03->enter($__internal_3fb0effb45c99e37d1f302b1a4774cf9d5b03863e3f5b2f741476d293ab88d03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_11ef377453a4cf38a5eec80aec9c2b3acef0432f4e2f522cbcb59ccd2bd883a8->leave($__internal_11ef377453a4cf38a5eec80aec9c2b3acef0432f4e2f522cbcb59ccd2bd883a8_prof);

        
        $__internal_3fb0effb45c99e37d1f302b1a4774cf9d5b03863e3f5b2f741476d293ab88d03->leave($__internal_3fb0effb45c99e37d1f302b1a4774cf9d5b03863e3f5b2f741476d293ab88d03_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
