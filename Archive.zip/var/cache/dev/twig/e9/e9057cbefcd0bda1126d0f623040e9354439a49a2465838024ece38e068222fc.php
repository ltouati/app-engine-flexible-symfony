<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_d617d7a96dc6587de56a780324fcde5304281639f469f468a6524e3f752dedc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4e6d2ca8531b6708dbaef3663cfe201dd096e55350ab2792fd44c24f5a4f4b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4e6d2ca8531b6708dbaef3663cfe201dd096e55350ab2792fd44c24f5a4f4b7->enter($__internal_b4e6d2ca8531b6708dbaef3663cfe201dd096e55350ab2792fd44c24f5a4f4b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_7d0459edd613589e2df776b9a38ae4621c65feaf7b991eda695cfbc627390711 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d0459edd613589e2df776b9a38ae4621c65feaf7b991eda695cfbc627390711->enter($__internal_7d0459edd613589e2df776b9a38ae4621c65feaf7b991eda695cfbc627390711_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_b4e6d2ca8531b6708dbaef3663cfe201dd096e55350ab2792fd44c24f5a4f4b7->leave($__internal_b4e6d2ca8531b6708dbaef3663cfe201dd096e55350ab2792fd44c24f5a4f4b7_prof);

        
        $__internal_7d0459edd613589e2df776b9a38ae4621c65feaf7b991eda695cfbc627390711->leave($__internal_7d0459edd613589e2df776b9a38ae4621c65feaf7b991eda695cfbc627390711_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
