<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_71a74dcd2b373081702b953ba1e44f31acc0f7721df696123c51edbe83c07baf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04b2031eb20c0d8e3b05dab1097a9140ec9ea08ff3ede85a835bf6e8a47a1adc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04b2031eb20c0d8e3b05dab1097a9140ec9ea08ff3ede85a835bf6e8a47a1adc->enter($__internal_04b2031eb20c0d8e3b05dab1097a9140ec9ea08ff3ede85a835bf6e8a47a1adc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        $__internal_ab770ee4cdfecb9bc1044b9ebfec4c179c1444a5e620126901800efe02891a62 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab770ee4cdfecb9bc1044b9ebfec4c179c1444a5e620126901800efe02891a62->enter($__internal_ab770ee4cdfecb9bc1044b9ebfec4c179c1444a5e620126901800efe02891a62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_04b2031eb20c0d8e3b05dab1097a9140ec9ea08ff3ede85a835bf6e8a47a1adc->leave($__internal_04b2031eb20c0d8e3b05dab1097a9140ec9ea08ff3ede85a835bf6e8a47a1adc_prof);

        
        $__internal_ab770ee4cdfecb9bc1044b9ebfec4c179c1444a5e620126901800efe02891a62->leave($__internal_ab770ee4cdfecb9bc1044b9ebfec4c179c1444a5e620126901800efe02891a62_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
", "@Framework/Form/button_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_widget.html.php");
    }
}
