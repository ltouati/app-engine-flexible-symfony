<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_15b6af3587b37ad2d9d553cdcf60aec9be0a12f9d176af83dee7cbfd2eac5c2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a5cb43391ff04d404146f8b74125e3bf4e98212eb1535ef4d7a291910982ccc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a5cb43391ff04d404146f8b74125e3bf4e98212eb1535ef4d7a291910982ccc->enter($__internal_6a5cb43391ff04d404146f8b74125e3bf4e98212eb1535ef4d7a291910982ccc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_8198c7a409e6c5302fbc85eb738390e95da9eeff7a45aebd3f9622e6707c13be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8198c7a409e6c5302fbc85eb738390e95da9eeff7a45aebd3f9622e6707c13be->enter($__internal_8198c7a409e6c5302fbc85eb738390e95da9eeff7a45aebd3f9622e6707c13be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_6a5cb43391ff04d404146f8b74125e3bf4e98212eb1535ef4d7a291910982ccc->leave($__internal_6a5cb43391ff04d404146f8b74125e3bf4e98212eb1535ef4d7a291910982ccc_prof);

        
        $__internal_8198c7a409e6c5302fbc85eb738390e95da9eeff7a45aebd3f9622e6707c13be->leave($__internal_8198c7a409e6c5302fbc85eb738390e95da9eeff7a45aebd3f9622e6707c13be_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.js.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
