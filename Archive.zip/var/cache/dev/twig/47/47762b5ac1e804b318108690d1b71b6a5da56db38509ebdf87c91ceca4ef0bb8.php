<?php

/* TwigBundle:Exception:error404.html.twig */
class __TwigTemplate_7b081fa9c155579bbea3e5f9799fcc5c01fc539c57e8ad8dec32979e500d0231 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error404.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dba0e5159cc2a92b656a39d5e2536ac1350d252aeb81dabe7bbbf6382c8fb94f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dba0e5159cc2a92b656a39d5e2536ac1350d252aeb81dabe7bbbf6382c8fb94f->enter($__internal_dba0e5159cc2a92b656a39d5e2536ac1350d252aeb81dabe7bbbf6382c8fb94f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error404.html.twig"));

        $__internal_13d3c49e1d665448a0effc198010c3ec85e5b75a099bfb71d7181e119fb547cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13d3c49e1d665448a0effc198010c3ec85e5b75a099bfb71d7181e119fb547cf->enter($__internal_13d3c49e1d665448a0effc198010c3ec85e5b75a099bfb71d7181e119fb547cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error404.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dba0e5159cc2a92b656a39d5e2536ac1350d252aeb81dabe7bbbf6382c8fb94f->leave($__internal_dba0e5159cc2a92b656a39d5e2536ac1350d252aeb81dabe7bbbf6382c8fb94f_prof);

        
        $__internal_13d3c49e1d665448a0effc198010c3ec85e5b75a099bfb71d7181e119fb547cf->leave($__internal_13d3c49e1d665448a0effc198010c3ec85e5b75a099bfb71d7181e119fb547cf_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_0b9421c6d12e004bc34aa264e1391b1c62070e83dc27a3fb6d805edb3cfc742a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0b9421c6d12e004bc34aa264e1391b1c62070e83dc27a3fb6d805edb3cfc742a->enter($__internal_0b9421c6d12e004bc34aa264e1391b1c62070e83dc27a3fb6d805edb3cfc742a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_5aaed66d2ec0ef8d96fec5e14a7248a15ec86621cab963f05b2d849830ca7dc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5aaed66d2ec0ef8d96fec5e14a7248a15ec86621cab963f05b2d849830ca7dc0->enter($__internal_5aaed66d2ec0ef8d96fec5e14a7248a15ec86621cab963f05b2d849830ca7dc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_5aaed66d2ec0ef8d96fec5e14a7248a15ec86621cab963f05b2d849830ca7dc0->leave($__internal_5aaed66d2ec0ef8d96fec5e14a7248a15ec86621cab963f05b2d849830ca7dc0_prof);

        
        $__internal_0b9421c6d12e004bc34aa264e1391b1c62070e83dc27a3fb6d805edb3cfc742a->leave($__internal_0b9421c6d12e004bc34aa264e1391b1c62070e83dc27a3fb6d805edb3cfc742a_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_08690f059bf7202da3143529af8c3ef3f2ff27d15c92aa8fac010553ea9542d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08690f059bf7202da3143529af8c3ef3f2ff27d15c92aa8fac010553ea9542d4->enter($__internal_08690f059bf7202da3143529af8c3ef3f2ff27d15c92aa8fac010553ea9542d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_d8504d60ec78c0fcfd8d355724fc46ab6d7183c80f3bb464bf38de18d5942355 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8504d60ec78c0fcfd8d355724fc46ab6d7183c80f3bb464bf38de18d5942355->enter($__internal_d8504d60ec78c0fcfd8d355724fc46ab6d7183c80f3bb464bf38de18d5942355_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => 404)), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_404.description"), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_404.suggestion", array("%url%" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index")));
        echo "
    </p>
";
        
        $__internal_d8504d60ec78c0fcfd8d355724fc46ab6d7183c80f3bb464bf38de18d5942355->leave($__internal_d8504d60ec78c0fcfd8d355724fc46ab6d7183c80f3bb464bf38de18d5942355_prof);

        
        $__internal_08690f059bf7202da3143529af8c3ef3f2ff27d15c92aa8fac010553ea9542d4->leave($__internal_08690f059bf7202da3143529af8c3ef3f2ff27d15c92aa8fac010553ea9542d4_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_e596664eafc5a8262bc2961acd87aaa513231da9755a3bbf16f10957059c5505 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e596664eafc5a8262bc2961acd87aaa513231da9755a3bbf16f10957059c5505->enter($__internal_e596664eafc5a8262bc2961acd87aaa513231da9755a3bbf16f10957059c5505_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_7ad92d905cda86f7b9cdfdc62f8d1f9a13a184cfde6d5f9901b3e6507f58905f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7ad92d905cda86f7b9cdfdc62f8d1f9a13a184cfde6d5f9901b3e6507f58905f->enter($__internal_7ad92d905cda86f7b9cdfdc62f8d1f9a13a184cfde6d5f9901b3e6507f58905f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_7ad92d905cda86f7b9cdfdc62f8d1f9a13a184cfde6d5f9901b3e6507f58905f->leave($__internal_7ad92d905cda86f7b9cdfdc62f8d1f9a13a184cfde6d5f9901b3e6507f58905f_prof);

        
        $__internal_e596664eafc5a8262bc2961acd87aaa513231da9755a3bbf16f10957059c5505->leave($__internal_e596664eafc5a8262bc2961acd87aaa513231da9755a3bbf16f10957059c5505_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render errors of type HTTP 404 (Not Found)

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See https://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'http_error.name'|trans({ '%status_code%': 404 }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error_404.description'|trans }}
    </p>
    <p>
        {{ 'http_error_404.suggestion'|trans({ '%url%': path('blog_index') })|raw }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error404.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/TwigBundle/views/Exception/error404.html.twig");
    }
}
