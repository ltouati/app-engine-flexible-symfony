<?php

/* admin/layout.html.twig */
class __TwigTemplate_37b7ea8e25dad31da2a231160beeab7b951a226ac2c6f75c55c34ef10b193a62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 8
        $this->parent = $this->loadTemplate("base.html.twig", "admin/layout.html.twig", 8);
        $this->blocks = array(
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_32f03bd6c1ee6bae31c6b7be63dd3e469d63744aebbe1547542b5d5a6d893b18 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32f03bd6c1ee6bae31c6b7be63dd3e469d63744aebbe1547542b5d5a6d893b18->enter($__internal_32f03bd6c1ee6bae31c6b7be63dd3e469d63744aebbe1547542b5d5a6d893b18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/layout.html.twig"));

        $__internal_30231bd28690dfd6f7ebf5ae8d619220ba10276e75571431830986139bf4aadb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_30231bd28690dfd6f7ebf5ae8d619220ba10276e75571431830986139bf4aadb->enter($__internal_30231bd28690dfd6f7ebf5ae8d619220ba10276e75571431830986139bf4aadb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_32f03bd6c1ee6bae31c6b7be63dd3e469d63744aebbe1547542b5d5a6d893b18->leave($__internal_32f03bd6c1ee6bae31c6b7be63dd3e469d63744aebbe1547542b5d5a6d893b18_prof);

        
        $__internal_30231bd28690dfd6f7ebf5ae8d619220ba10276e75571431830986139bf4aadb->leave($__internal_30231bd28690dfd6f7ebf5ae8d619220ba10276e75571431830986139bf4aadb_prof);

    }

    // line 10
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_1e93eb68eb2a4fb1045fe3152778cd6aaacd656a0cb13b4aa883ee3c6e994070 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e93eb68eb2a4fb1045fe3152778cd6aaacd656a0cb13b4aa883ee3c6e994070->enter($__internal_1e93eb68eb2a4fb1045fe3152778cd6aaacd656a0cb13b4aa883ee3c6e994070_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_db8202d83e39ee7ccb6f156b123416f9c19c0b7fc94f9f88e93d8c81e9929ee3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db8202d83e39ee7ccb6f156b123416f9c19c0b7fc94f9f88e93d8c81e9929ee3->enter($__internal_db8202d83e39ee7ccb6f156b123416f9c19c0b7fc94f9f88e93d8c81e9929ee3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 11
        echo "    <li>
        <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">
            <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> ";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.post_list"), "html", null, true);
        echo "
        </a>
    </li>
    <li>
        <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.back_to_blog"), "html", null, true);
        echo "
        </a>
    </li>
";
        
        $__internal_db8202d83e39ee7ccb6f156b123416f9c19c0b7fc94f9f88e93d8c81e9929ee3->leave($__internal_db8202d83e39ee7ccb6f156b123416f9c19c0b7fc94f9f88e93d8c81e9929ee3_prof);

        
        $__internal_1e93eb68eb2a4fb1045fe3152778cd6aaacd656a0cb13b4aa883ee3c6e994070->leave($__internal_1e93eb68eb2a4fb1045fe3152778cd6aaacd656a0cb13b4aa883ee3c6e994070_prof);

    }

    public function getTemplateName()
    {
        return "admin/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 18,  63 => 17,  56 => 13,  52 => 12,  49 => 11,  40 => 10,  11 => 8,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template of the all backend pages. Since this layout is similar
   to the global layout, we inherit from it to just change the contents of some
   blocks. In practice, backend templates are using a three-level inheritance,
   showing how powerful, yet easy to use, is Twig's inheritance mechanism.
   See https://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
{% extends 'base.html.twig' %}

{% block header_navigation_links %}
    <li>
        <a href=\"{{ path('admin_post_index') }}\">
            <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> {{ 'menu.post_list'|trans }}
        </a>
    </li>
    <li>
        <a href=\"{{ path('blog_index') }}\">
            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> {{ 'menu.back_to_blog'|trans }}
        </a>
    </li>
{% endblock %}
", "admin/layout.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/admin/layout.html.twig");
    }
}
