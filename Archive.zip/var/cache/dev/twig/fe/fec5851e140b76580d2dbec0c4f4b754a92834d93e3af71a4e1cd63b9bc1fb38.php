<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_b7967c984c96c672d4fb3bda34e68768f07f6dd36eff4aaaa0fdf43a93a51041 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f97079e1c756e9d32875a1b9f2ec0d32e1298a7ed77ba6a5494a4d8713eb9db8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f97079e1c756e9d32875a1b9f2ec0d32e1298a7ed77ba6a5494a4d8713eb9db8->enter($__internal_f97079e1c756e9d32875a1b9f2ec0d32e1298a7ed77ba6a5494a4d8713eb9db8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_605b50d1afe0670cc5d43ae2e9e55092d9731e43b851256341b7d1f992953039 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_605b50d1afe0670cc5d43ae2e9e55092d9731e43b851256341b7d1f992953039->enter($__internal_605b50d1afe0670cc5d43ae2e9e55092d9731e43b851256341b7d1f992953039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_f97079e1c756e9d32875a1b9f2ec0d32e1298a7ed77ba6a5494a4d8713eb9db8->leave($__internal_f97079e1c756e9d32875a1b9f2ec0d32e1298a7ed77ba6a5494a4d8713eb9db8_prof);

        
        $__internal_605b50d1afe0670cc5d43ae2e9e55092d9731e43b851256341b7d1f992953039->leave($__internal_605b50d1afe0670cc5d43ae2e9e55092d9731e43b851256341b7d1f992953039_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_row.html.php");
    }
}
