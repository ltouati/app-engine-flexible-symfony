<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_13544825b2c46c9b781239653fdcb142c053f24e2f4e85ddbaa0393f4b6c4783 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_62919608146b23b47115eb327e29fe745775e0e82f7a2258442efbcc53ade74c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_62919608146b23b47115eb327e29fe745775e0e82f7a2258442efbcc53ade74c->enter($__internal_62919608146b23b47115eb327e29fe745775e0e82f7a2258442efbcc53ade74c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_09cb0c7b502073e0c70f43cabf8a0cd038c992cab51b9f3768a203dda17ba646 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09cb0c7b502073e0c70f43cabf8a0cd038c992cab51b9f3768a203dda17ba646->enter($__internal_09cb0c7b502073e0c70f43cabf8a0cd038c992cab51b9f3768a203dda17ba646_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_62919608146b23b47115eb327e29fe745775e0e82f7a2258442efbcc53ade74c->leave($__internal_62919608146b23b47115eb327e29fe745775e0e82f7a2258442efbcc53ade74c_prof);

        
        $__internal_09cb0c7b502073e0c70f43cabf8a0cd038c992cab51b9f3768a203dda17ba646->leave($__internal_09cb0c7b502073e0c70f43cabf8a0cd038c992cab51b9f3768a203dda17ba646_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/submit_widget.html.php");
    }
}
