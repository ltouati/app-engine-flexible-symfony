<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_4b759b8f62ce128f2465229086a3f1100edf3a4b22ad0099ba271352266ce191 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6cf72e4ddde3b71e3a448c4776655dcef03fe84a620db83073026a039d299866 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cf72e4ddde3b71e3a448c4776655dcef03fe84a620db83073026a039d299866->enter($__internal_6cf72e4ddde3b71e3a448c4776655dcef03fe84a620db83073026a039d299866_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_8e8948b350445671322b95c12ee8b390c37057b849ee618c9b6413c9baaee607 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e8948b350445671322b95c12ee8b390c37057b849ee618c9b6413c9baaee607->enter($__internal_8e8948b350445671322b95c12ee8b390c37057b849ee618c9b6413c9baaee607_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_6cf72e4ddde3b71e3a448c4776655dcef03fe84a620db83073026a039d299866->leave($__internal_6cf72e4ddde3b71e3a448c4776655dcef03fe84a620db83073026a039d299866_prof);

        
        $__internal_8e8948b350445671322b95c12ee8b390c37057b849ee618c9b6413c9baaee607->leave($__internal_8e8948b350445671322b95c12ee8b390c37057b849ee618c9b6413c9baaee607_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Icon/forward.svg");
    }
}
