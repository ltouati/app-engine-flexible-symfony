<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_457d7cff7902eb196daac954e3a9f2e9f18fae1e79ecd62f6a77bdae9def5cdf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_32d7f6aaaee01e310199db3af253d55f40b5a4a397682ea0992a6e6f3eee73d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32d7f6aaaee01e310199db3af253d55f40b5a4a397682ea0992a6e6f3eee73d3->enter($__internal_32d7f6aaaee01e310199db3af253d55f40b5a4a397682ea0992a6e6f3eee73d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_c6db82610ccbb414c6b76eb7673b46b801d7faa2ffc52426347e4fcef2da509f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6db82610ccbb414c6b76eb7673b46b801d7faa2ffc52426347e4fcef2da509f->enter($__internal_c6db82610ccbb414c6b76eb7673b46b801d7faa2ffc52426347e4fcef2da509f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_32d7f6aaaee01e310199db3af253d55f40b5a4a397682ea0992a6e6f3eee73d3->leave($__internal_32d7f6aaaee01e310199db3af253d55f40b5a4a397682ea0992a6e6f3eee73d3_prof);

        
        $__internal_c6db82610ccbb414c6b76eb7673b46b801d7faa2ffc52426347e4fcef2da509f->leave($__internal_c6db82610ccbb414c6b76eb7673b46b801d7faa2ffc52426347e4fcef2da509f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget.html.php");
    }
}
