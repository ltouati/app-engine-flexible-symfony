<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_72adefa0aead0df11a8bf005f80dbe82947a939d0282719c9e42544a439af676 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b04ec9eef95473355b2fd264d6922a7d64f45d8ece47ca0facc71798bfe16367 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b04ec9eef95473355b2fd264d6922a7d64f45d8ece47ca0facc71798bfe16367->enter($__internal_b04ec9eef95473355b2fd264d6922a7d64f45d8ece47ca0facc71798bfe16367_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_abd4e27cc0e3c925f95ad1fb867e9645fedeaa33ea6aa41f3c8b630a190a4ae1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_abd4e27cc0e3c925f95ad1fb867e9645fedeaa33ea6aa41f3c8b630a190a4ae1->enter($__internal_abd4e27cc0e3c925f95ad1fb867e9645fedeaa33ea6aa41f3c8b630a190a4ae1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_b04ec9eef95473355b2fd264d6922a7d64f45d8ece47ca0facc71798bfe16367->leave($__internal_b04ec9eef95473355b2fd264d6922a7d64f45d8ece47ca0facc71798bfe16367_prof);

        
        $__internal_abd4e27cc0e3c925f95ad1fb867e9645fedeaa33ea6aa41f3c8b630a190a4ae1->leave($__internal_abd4e27cc0e3c925f95ad1fb867e9645fedeaa33ea6aa41f3c8b630a190a4ae1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
