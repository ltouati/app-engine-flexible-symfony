<?php

/* :admin/blog:new.html.twig */
class __TwigTemplate_8b43b0e071ce946e20ae95cc9747b4120ec7c1b8ebf36e3a48ab8bcbc38e47c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", ":admin/blog:new.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f579d409aa7c7dde2f3187c1d3ed7990ae02aea5babcedf300149c8dc97fd0d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f579d409aa7c7dde2f3187c1d3ed7990ae02aea5babcedf300149c8dc97fd0d4->enter($__internal_f579d409aa7c7dde2f3187c1d3ed7990ae02aea5babcedf300149c8dc97fd0d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:new.html.twig"));

        $__internal_97bfff87d52cd34f1b897c2e268a1cf4b6f7da118cbfaf94201b01daeef0a530 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97bfff87d52cd34f1b897c2e268a1cf4b6f7da118cbfaf94201b01daeef0a530->enter($__internal_97bfff87d52cd34f1b897c2e268a1cf4b6f7da118cbfaf94201b01daeef0a530_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f579d409aa7c7dde2f3187c1d3ed7990ae02aea5babcedf300149c8dc97fd0d4->leave($__internal_f579d409aa7c7dde2f3187c1d3ed7990ae02aea5babcedf300149c8dc97fd0d4_prof);

        
        $__internal_97bfff87d52cd34f1b897c2e268a1cf4b6f7da118cbfaf94201b01daeef0a530->leave($__internal_97bfff87d52cd34f1b897c2e268a1cf4b6f7da118cbfaf94201b01daeef0a530_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_ed2060ace219a41f6e70e8c9e11a6b220d0c77581eb95de76295a8c94d16885c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed2060ace219a41f6e70e8c9e11a6b220d0c77581eb95de76295a8c94d16885c->enter($__internal_ed2060ace219a41f6e70e8c9e11a6b220d0c77581eb95de76295a8c94d16885c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_f7383b9f99b8a1b4984af57289dd33417336d02dce70208b782c198c6028f626 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7383b9f99b8a1b4984af57289dd33417336d02dce70208b782c198c6028f626->enter($__internal_f7383b9f99b8a1b4984af57289dd33417336d02dce70208b782c198c6028f626_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_new";
        
        $__internal_f7383b9f99b8a1b4984af57289dd33417336d02dce70208b782c198c6028f626->leave($__internal_f7383b9f99b8a1b4984af57289dd33417336d02dce70208b782c198c6028f626_prof);

        
        $__internal_ed2060ace219a41f6e70e8c9e11a6b220d0c77581eb95de76295a8c94d16885c->leave($__internal_ed2060ace219a41f6e70e8c9e11a6b220d0c77581eb95de76295a8c94d16885c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_f648db120c7c035f2650de7d31f63ad7eb8a6731dc5037a7779bfc30e637e1ce = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f648db120c7c035f2650de7d31f63ad7eb8a6731dc5037a7779bfc30e637e1ce->enter($__internal_f648db120c7c035f2650de7d31f63ad7eb8a6731dc5037a7779bfc30e637e1ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_d8bad56515b1eebfb43ca6caf85243c59c45012a424e416733da19ab473daa67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8bad56515b1eebfb43ca6caf85243c59c45012a424e416733da19ab473daa67->enter($__internal_d8bad56515b1eebfb43ca6caf85243c59c45012a424e416733da19ab473daa67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.post_new"), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "title", array()), 'row');
        echo "
        ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "summary", array()), 'row');
        echo "
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "content", array()), 'row');
        echo "
        ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "publishedAt", array()), 'row');
        echo "
        ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tags", array()), 'row');
        echo "

        <input type=\"submit\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.create_post"), "html", null, true);
        echo "\" class=\"btn btn-primary\" />
        ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveAndCreateNew", array()), 'widget', array("label" => "label.save_and_create_new", "attr" => array("class" => "btn btn-primary")));
        echo "
        <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\" class=\"btn btn-link\">
            ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.back_to_list"), "html", null, true);
        echo "
        </a>
    ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_d8bad56515b1eebfb43ca6caf85243c59c45012a424e416733da19ab473daa67->leave($__internal_d8bad56515b1eebfb43ca6caf85243c59c45012a424e416733da19ab473daa67_prof);

        
        $__internal_f648db120c7c035f2650de7d31f63ad7eb8a6731dc5037a7779bfc30e637e1ce->leave($__internal_f648db120c7c035f2650de7d31f63ad7eb8a6731dc5037a7779bfc30e637e1ce_prof);

    }

    // line 23
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_f74efe2961f5343d9a7a89fbcdbf2ae431cbd0d97c58a9f0debea0bd8fded8d8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f74efe2961f5343d9a7a89fbcdbf2ae431cbd0d97c58a9f0debea0bd8fded8d8->enter($__internal_f74efe2961f5343d9a7a89fbcdbf2ae431cbd0d97c58a9f0debea0bd8fded8d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_3d49cc0f2c4a1ad46ce5eccba561969296e53c5492b72ae1dd226661fe422db7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d49cc0f2c4a1ad46ce5eccba561969296e53c5492b72ae1dd226661fe422db7->enter($__internal_3d49cc0f2c4a1ad46ce5eccba561969296e53c5492b72ae1dd226661fe422db7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 24
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 26
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_3d49cc0f2c4a1ad46ce5eccba561969296e53c5492b72ae1dd226661fe422db7->leave($__internal_3d49cc0f2c4a1ad46ce5eccba561969296e53c5492b72ae1dd226661fe422db7_prof);

        
        $__internal_f74efe2961f5343d9a7a89fbcdbf2ae431cbd0d97c58a9f0debea0bd8fded8d8->leave($__internal_f74efe2961f5343d9a7a89fbcdbf2ae431cbd0d97c58a9f0debea0bd8fded8d8_prof);

    }

    public function getTemplateName()
    {
        return ":admin/blog:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 26,  138 => 24,  129 => 23,  117 => 20,  112 => 18,  108 => 17,  104 => 16,  100 => 15,  95 => 13,  91 => 12,  87 => 11,  83 => 10,  79 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_new' %}

{% block main %}
    <h1>{{ 'title.post_new'|trans }}</h1>

    {{ form_start(form) }}
        {{ form_row(form.title) }}
        {{ form_row(form.summary) }}
        {{ form_row(form.content) }}
        {{ form_row(form.publishedAt) }}
        {{ form_row(form.tags) }}

        <input type=\"submit\" value=\"{{ 'label.create_post'|trans }}\" class=\"btn btn-primary\" />
        {{ form_widget(form.saveAndCreateNew, {label: 'label.save_and_create_new', attr: {class: 'btn btn-primary'}}) }}
        <a href=\"{{ path('admin_post_index') }}\" class=\"btn btn-link\">
            {{ 'action.back_to_list'|trans }}
        </a>
    {{ form_end(form) }}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", ":admin/blog:new.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/admin/blog/new.html.twig");
    }
}
