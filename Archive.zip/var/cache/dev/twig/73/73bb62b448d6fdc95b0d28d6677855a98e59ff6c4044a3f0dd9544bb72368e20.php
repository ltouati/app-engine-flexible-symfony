<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_63920aa4c56efded58d7c20a61fd0edfa0c26a2e022394885fc058d2f1efaa1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9df16bd9bd7d41b4675292f10b4f034072b85d8fd9c447c956dfebb8f59ef5f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9df16bd9bd7d41b4675292f10b4f034072b85d8fd9c447c956dfebb8f59ef5f8->enter($__internal_9df16bd9bd7d41b4675292f10b4f034072b85d8fd9c447c956dfebb8f59ef5f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_b63b3f401940e4645e8bf9f6c772bf07aa7df96a4c87e8e08ac73e29c84d1f2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b63b3f401940e4645e8bf9f6c772bf07aa7df96a4c87e8e08ac73e29c84d1f2f->enter($__internal_b63b3f401940e4645e8bf9f6c772bf07aa7df96a4c87e8e08ac73e29c84d1f2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_9df16bd9bd7d41b4675292f10b4f034072b85d8fd9c447c956dfebb8f59ef5f8->leave($__internal_9df16bd9bd7d41b4675292f10b4f034072b85d8fd9c447c956dfebb8f59ef5f8_prof);

        
        $__internal_b63b3f401940e4645e8bf9f6c772bf07aa7df96a4c87e8e08ac73e29c84d1f2f->leave($__internal_b63b3f401940e4645e8bf9f6c772bf07aa7df96a4c87e8e08ac73e29c84d1f2f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
