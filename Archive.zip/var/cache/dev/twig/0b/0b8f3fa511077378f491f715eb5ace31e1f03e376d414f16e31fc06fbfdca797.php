<?php

/* :form:fields.html.twig */
class __TwigTemplate_6e91f1bb61273cc6ff75a9a8408a3c57ebee8a5417eb07f6eeed68dd5de5a428 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
            'tags_input_widget' => array($this, 'block_tags_input_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_581caa2540e528d25117b8072b24e2991b2afc9f5eda5c13ece1f7c22f17d5af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_581caa2540e528d25117b8072b24e2991b2afc9f5eda5c13ece1f7c22f17d5af->enter($__internal_581caa2540e528d25117b8072b24e2991b2afc9f5eda5c13ece1f7c22f17d5af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":form:fields.html.twig"));

        $__internal_37e68ee9913a53ae841f1623da6d67116e4febe09a6b44596c9c79d59116c80f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37e68ee9913a53ae841f1623da6d67116e4febe09a6b44596c9c79d59116c80f->enter($__internal_37e68ee9913a53ae841f1623da6d67116e4febe09a6b44596c9c79d59116c80f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":form:fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        // line 18
        echo "
";
        // line 19
        $this->displayBlock('tags_input_widget', $context, $blocks);
        
        $__internal_581caa2540e528d25117b8072b24e2991b2afc9f5eda5c13ece1f7c22f17d5af->leave($__internal_581caa2540e528d25117b8072b24e2991b2afc9f5eda5c13ece1f7c22f17d5af_prof);

        
        $__internal_37e68ee9913a53ae841f1623da6d67116e4febe09a6b44596c9c79d59116c80f->leave($__internal_37e68ee9913a53ae841f1623da6d67116e4febe09a6b44596c9c79d59116c80f_prof);

    }

    // line 10
    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_1af00dfa3abeeb59502b8c74633a453ff1d2382370e88c591c95c28cfc6f67b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1af00dfa3abeeb59502b8c74633a453ff1d2382370e88c591c95c28cfc6f67b3->enter($__internal_1af00dfa3abeeb59502b8c74633a453ff1d2382370e88c591c95c28cfc6f67b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        $__internal_4dd63d0904cacd42700d58727e18a920b3f3f91b50fdfc9c69f721a5f9cc92db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4dd63d0904cacd42700d58727e18a920b3f3f91b50fdfc9c69f721a5f9cc92db->enter($__internal_4dd63d0904cacd42700d58727e18a920b3f3f91b50fdfc9c69f721a5f9cc92db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        ";
        // line 12
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
";
        
        $__internal_4dd63d0904cacd42700d58727e18a920b3f3f91b50fdfc9c69f721a5f9cc92db->leave($__internal_4dd63d0904cacd42700d58727e18a920b3f3f91b50fdfc9c69f721a5f9cc92db_prof);

        
        $__internal_1af00dfa3abeeb59502b8c74633a453ff1d2382370e88c591c95c28cfc6f67b3->leave($__internal_1af00dfa3abeeb59502b8c74633a453ff1d2382370e88c591c95c28cfc6f67b3_prof);

    }

    // line 19
    public function block_tags_input_widget($context, array $blocks = array())
    {
        $__internal_9e3b2865815498dd9d128a5161851974d3191b9efc2561708cdf0c80fad078c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e3b2865815498dd9d128a5161851974d3191b9efc2561708cdf0c80fad078c7->enter($__internal_9e3b2865815498dd9d128a5161851974d3191b9efc2561708cdf0c80fad078c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tags_input_widget"));

        $__internal_48c7b76683114296438a14f5fb6844c1fe535125b61ab93b47793019094637a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48c7b76683114296438a14f5fb6844c1fe535125b61ab93b47793019094637a7->enter($__internal_48c7b76683114296438a14f5fb6844c1fe535125b61ab93b47793019094637a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tags_input_widget"));

        // line 20
        echo "    <div class=\"input-group\">
        ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget', array("attr" => array("data-toggle" => "tagsinput", "data-tags" => twig_jsonencode_filter((isset($context["tags"]) ? $context["tags"] : $this->getContext($context, "tags"))))));
        echo "
        <span class=\"input-group-addon\">
            <span class=\"fa fa-tags\" aria-hidden=\"true\"></span>
        </span>
    </div>
";
        
        $__internal_48c7b76683114296438a14f5fb6844c1fe535125b61ab93b47793019094637a7->leave($__internal_48c7b76683114296438a14f5fb6844c1fe535125b61ab93b47793019094637a7_prof);

        
        $__internal_9e3b2865815498dd9d128a5161851974d3191b9efc2561708cdf0c80fad078c7->leave($__internal_9e3b2865815498dd9d128a5161851974d3191b9efc2561708cdf0c80fad078c7_prof);

    }

    public function getTemplateName()
    {
        return ":form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 21,  82 => 20,  73 => 19,  57 => 12,  54 => 11,  45 => 10,  35 => 19,  32 => 18,  30 => 10,  27 => 9,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See https://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        {{ block('datetime_widget') }}
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
{% endblock %}

{% block tags_input_widget %}
    <div class=\"input-group\">
        {{ form_widget(form, {'attr': {'data-toggle': 'tagsinput', 'data-tags': tags|json_encode}}) }}
        <span class=\"input-group-addon\">
            <span class=\"fa fa-tags\" aria-hidden=\"true\"></span>
        </span>
    </div>
{% endblock %}
", ":form:fields.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/form/fields.html.twig");
    }
}
