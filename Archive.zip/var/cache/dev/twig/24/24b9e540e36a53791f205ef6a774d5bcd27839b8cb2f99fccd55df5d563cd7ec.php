<?php

/* :admin/blog:edit.html.twig */
class __TwigTemplate_aae68e71b431ff6c6b4c25e13f454ea8bbeaf79693e74f0895e5efb3fe703e0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", ":admin/blog:edit.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e30f0f68fbb88f2329506efc2b7cf11c6e086ada3161561433b5a4a810c5193 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e30f0f68fbb88f2329506efc2b7cf11c6e086ada3161561433b5a4a810c5193->enter($__internal_8e30f0f68fbb88f2329506efc2b7cf11c6e086ada3161561433b5a4a810c5193_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:edit.html.twig"));

        $__internal_42ae62cb3da07d25c2b9e9ae656684c66f308b6d849af0760702f72eaf459d77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42ae62cb3da07d25c2b9e9ae656684c66f308b6d849af0760702f72eaf459d77->enter($__internal_42ae62cb3da07d25c2b9e9ae656684c66f308b6d849af0760702f72eaf459d77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8e30f0f68fbb88f2329506efc2b7cf11c6e086ada3161561433b5a4a810c5193->leave($__internal_8e30f0f68fbb88f2329506efc2b7cf11c6e086ada3161561433b5a4a810c5193_prof);

        
        $__internal_42ae62cb3da07d25c2b9e9ae656684c66f308b6d849af0760702f72eaf459d77->leave($__internal_42ae62cb3da07d25c2b9e9ae656684c66f308b6d849af0760702f72eaf459d77_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_a00e555fcd1958ae50743cf189adafc827b2e96dcc39b6abf8b56679f6fa463c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a00e555fcd1958ae50743cf189adafc827b2e96dcc39b6abf8b56679f6fa463c->enter($__internal_a00e555fcd1958ae50743cf189adafc827b2e96dcc39b6abf8b56679f6fa463c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_c1408395c467ef33cd87b4b2e8e9266e9c660755de60c0981aa59e9b558c661a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1408395c467ef33cd87b4b2e8e9266e9c660755de60c0981aa59e9b558c661a->enter($__internal_c1408395c467ef33cd87b4b2e8e9266e9c660755de60c0981aa59e9b558c661a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_edit";
        
        $__internal_c1408395c467ef33cd87b4b2e8e9266e9c660755de60c0981aa59e9b558c661a->leave($__internal_c1408395c467ef33cd87b4b2e8e9266e9c660755de60c0981aa59e9b558c661a_prof);

        
        $__internal_a00e555fcd1958ae50743cf189adafc827b2e96dcc39b6abf8b56679f6fa463c->leave($__internal_a00e555fcd1958ae50743cf189adafc827b2e96dcc39b6abf8b56679f6fa463c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_e6bc1ed13dcc5befe6bef8fdd47845443951e2d848ef1b184c5c93bfdc1f21c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6bc1ed13dcc5befe6bef8fdd47845443951e2d848ef1b184c5c93bfdc1f21c8->enter($__internal_e6bc1ed13dcc5befe6bef8fdd47845443951e2d848ef1b184c5c93bfdc1f21c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_1e8d42fca287845b11a7df2637816d9ab4aee1b868eda1ee89d8b021ca20f506 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e8d42fca287845b11a7df2637816d9ab4aee1b868eda1ee89d8b021ca20f506->enter($__internal_1e8d42fca287845b11a7df2637816d9ab4aee1b868eda1ee89d8b021ca20f506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.edit_post", array("%id%" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo twig_include($this->env, $context, "admin/blog/_form.html.twig", array("form" =>         // line 9
(isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "button_label" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.save"), "include_back_to_home_link" => true), false);
        // line 12
        echo "
";
        
        $__internal_1e8d42fca287845b11a7df2637816d9ab4aee1b868eda1ee89d8b021ca20f506->leave($__internal_1e8d42fca287845b11a7df2637816d9ab4aee1b868eda1ee89d8b021ca20f506_prof);

        
        $__internal_e6bc1ed13dcc5befe6bef8fdd47845443951e2d848ef1b184c5c93bfdc1f21c8->leave($__internal_e6bc1ed13dcc5befe6bef8fdd47845443951e2d848ef1b184c5c93bfdc1f21c8_prof);

    }

    // line 15
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_f370200fcd68bb5bb8638b466c33c820b7b811123a9b4a7014c80c5099a94261 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f370200fcd68bb5bb8638b466c33c820b7b811123a9b4a7014c80c5099a94261->enter($__internal_f370200fcd68bb5bb8638b466c33c820b7b811123a9b4a7014c80c5099a94261_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_198312caa5c38ea6f3271d2fc6725ecb939d20f70cf0352249dd5ec0fa3c304a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_198312caa5c38ea6f3271d2fc6725ecb939d20f70cf0352249dd5ec0fa3c304a->enter($__internal_198312caa5c38ea6f3271d2fc6725ecb939d20f70cf0352249dd5ec0fa3c304a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 16
        echo "    <div class=\"section\">
        <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_show", array("id" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-eye\" aria-hidden=\"true\"></i> ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.show_post"), "html", null, true);
        echo "
        </a>
    </div>

    <div class=\"section actions\">
        ";
        // line 23
        echo twig_include($this->env, $context, "admin/blog/_delete_form.html.twig", array("post" => (isset($context["post"]) ? $context["post"] : $this->getContext($context, "post"))), false);
        echo "
    </div>

    ";
        // line 26
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 28
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_198312caa5c38ea6f3271d2fc6725ecb939d20f70cf0352249dd5ec0fa3c304a->leave($__internal_198312caa5c38ea6f3271d2fc6725ecb939d20f70cf0352249dd5ec0fa3c304a_prof);

        
        $__internal_f370200fcd68bb5bb8638b466c33c820b7b811123a9b4a7014c80c5099a94261->leave($__internal_f370200fcd68bb5bb8638b466c33c820b7b811123a9b4a7014c80c5099a94261_prof);

    }

    public function getTemplateName()
    {
        return ":admin/blog:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 28,  119 => 26,  113 => 23,  105 => 18,  101 => 17,  98 => 16,  89 => 15,  78 => 12,  76 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_edit' %}

{% block main %}
    <h1>{{ 'title.edit_post'|trans({'%id%': post.id}) }}</h1>

    {{ include('admin/blog/_form.html.twig', {
        form: form,
        button_label: 'action.save'|trans,
        include_back_to_home_link: true,
    }, with_context = false) }}
{% endblock %}

{% block sidebar %}
    <div class=\"section\">
        <a href=\"{{ path('admin_post_show', {id: post.id}) }}\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-eye\" aria-hidden=\"true\"></i> {{ 'action.show_post'|trans }}
        </a>
    </div>

    <div class=\"section actions\">
        {{ include('admin/blog/_delete_form.html.twig', {post: post}, with_context = false) }}
    </div>

    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", ":admin/blog:edit.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/admin/blog/edit.html.twig");
    }
}
