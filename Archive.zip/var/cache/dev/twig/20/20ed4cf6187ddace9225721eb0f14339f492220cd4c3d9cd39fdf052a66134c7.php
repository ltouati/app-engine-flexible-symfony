<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_bc799604784ddcff2c0f58ef132f938ac6507322a0dd9c94e4457b11192627b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_be1979b2bdc837e8b11529b05f975b4eedbd135f4d75aa979024363c71534b13 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be1979b2bdc837e8b11529b05f975b4eedbd135f4d75aa979024363c71534b13->enter($__internal_be1979b2bdc837e8b11529b05f975b4eedbd135f4d75aa979024363c71534b13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_d0fd9d6c26816cd0eacf63011683a62c957a91eb361b9ecd30a146458ce73701 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0fd9d6c26816cd0eacf63011683a62c957a91eb361b9ecd30a146458ce73701->enter($__internal_d0fd9d6c26816cd0eacf63011683a62c957a91eb361b9ecd30a146458ce73701_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_be1979b2bdc837e8b11529b05f975b4eedbd135f4d75aa979024363c71534b13->leave($__internal_be1979b2bdc837e8b11529b05f975b4eedbd135f4d75aa979024363c71534b13_prof);

        
        $__internal_d0fd9d6c26816cd0eacf63011683a62c957a91eb361b9ecd30a146458ce73701->leave($__internal_d0fd9d6c26816cd0eacf63011683a62c957a91eb361b9ecd30a146458ce73701_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
