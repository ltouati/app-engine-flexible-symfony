<?php

/* blog/index.html.twig */
class __TwigTemplate_838672c309392da07b5e311ebb71b7fceb5177bceacab9f2c49e42ba857459cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d75a6035a6f4f1047b2abec3c010d437a1f4b162b52a6726f75afabd4dd23f88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d75a6035a6f4f1047b2abec3c010d437a1f4b162b52a6726f75afabd4dd23f88->enter($__internal_d75a6035a6f4f1047b2abec3c010d437a1f4b162b52a6726f75afabd4dd23f88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $__internal_f222d71a295ddb7ed491603dbaba63dc80b8ca556f38d10f0ca97851b7249cc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f222d71a295ddb7ed491603dbaba63dc80b8ca556f38d10f0ca97851b7249cc1->enter($__internal_f222d71a295ddb7ed491603dbaba63dc80b8ca556f38d10f0ca97851b7249cc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d75a6035a6f4f1047b2abec3c010d437a1f4b162b52a6726f75afabd4dd23f88->leave($__internal_d75a6035a6f4f1047b2abec3c010d437a1f4b162b52a6726f75afabd4dd23f88_prof);

        
        $__internal_f222d71a295ddb7ed491603dbaba63dc80b8ca556f38d10f0ca97851b7249cc1->leave($__internal_f222d71a295ddb7ed491603dbaba63dc80b8ca556f38d10f0ca97851b7249cc1_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_3c31a562422cebebe8d61d4a0e27224c7887a67f914332d3cc5238f45364e40c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c31a562422cebebe8d61d4a0e27224c7887a67f914332d3cc5238f45364e40c->enter($__internal_3c31a562422cebebe8d61d4a0e27224c7887a67f914332d3cc5238f45364e40c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_6c88732d40f6a8a94936e2d6d1e4dbf4653f5594a1fe0e4b3d55780637283f7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c88732d40f6a8a94936e2d6d1e4dbf4653f5594a1fe0e4b3d55780637283f7a->enter($__internal_6c88732d40f6a8a94936e2d6d1e4dbf4653f5594a1fe0e4b3d55780637283f7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "blog_index";
        
        $__internal_6c88732d40f6a8a94936e2d6d1e4dbf4653f5594a1fe0e4b3d55780637283f7a->leave($__internal_6c88732d40f6a8a94936e2d6d1e4dbf4653f5594a1fe0e4b3d55780637283f7a_prof);

        
        $__internal_3c31a562422cebebe8d61d4a0e27224c7887a67f914332d3cc5238f45364e40c->leave($__internal_3c31a562422cebebe8d61d4a0e27224c7887a67f914332d3cc5238f45364e40c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_12eb807b88c80da88d1788b8978c5a55ec56ec8decf8b221fc30131d765d40dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12eb807b88c80da88d1788b8978c5a55ec56ec8decf8b221fc30131d765d40dd->enter($__internal_12eb807b88c80da88d1788b8978c5a55ec56ec8decf8b221fc30131d765d40dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_4d5ceec1e9475e30ab5a00589e65b9d21594e2fefa4b828311fef235c80fc31d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d5ceec1e9475e30ab5a00589e65b9d21594e2fefa4b828311fef235c80fc31d->enter($__internal_4d5ceec1e9475e30ab5a00589e65b9d21594e2fefa4b828311fef235c80fc31d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 7
            echo "        <article class=\"post\">
            <h2>
                <a href=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_post", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\">
                    ";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "
                </a>
            </h2>

            <p class=\"post-metadata\">
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> ";
            // line 15
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
            echo "</span>
                <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "author", array()), "fullName", array()), "html", null, true);
            echo "</span>
            </p>

            ";
            // line 19
            echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["post"], "summary", array()));
            echo "

            ";
            // line 21
            echo twig_include($this->env, $context, "blog/_post_tags.html.twig");
            echo "
        </article>
    ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 24
            echo "        <div class=\"well\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_posts_found"), "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "
    ";
        // line 27
        if ($this->getAttribute((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")), "haveToPaginate", array())) {
            // line 28
            echo "        <div class=\"navigation text-center\">
            ";
            // line 29
            echo $this->env->getExtension('WhiteOctober\PagerfantaBundle\Twig\PagerfantaExtension')->renderPagerfanta((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")), "twitter_bootstrap3_translated", array("routeName" => "blog_index_paginated"));
            echo "
        </div>
    ";
        }
        
        $__internal_4d5ceec1e9475e30ab5a00589e65b9d21594e2fefa4b828311fef235c80fc31d->leave($__internal_4d5ceec1e9475e30ab5a00589e65b9d21594e2fefa4b828311fef235c80fc31d_prof);

        
        $__internal_12eb807b88c80da88d1788b8978c5a55ec56ec8decf8b221fc30131d765d40dd->leave($__internal_12eb807b88c80da88d1788b8978c5a55ec56ec8decf8b221fc30131d765d40dd_prof);

    }

    // line 34
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_2a220b75f4c6d3710e7fd70bc24ea0b5b72787da8707da3ae7429cd7be082cba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a220b75f4c6d3710e7fd70bc24ea0b5b72787da8707da3ae7429cd7be082cba->enter($__internal_2a220b75f4c6d3710e7fd70bc24ea0b5b72787da8707da3ae7429cd7be082cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_ece89ae6efc46d54a7ac6bfd0a946cbdccf09edf9723d51785947e28f447af8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ece89ae6efc46d54a7ac6bfd0a946cbdccf09edf9723d51785947e28f447af8e->enter($__internal_ece89ae6efc46d54a7ac6bfd0a946cbdccf09edf9723d51785947e28f447af8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 35
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 37
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
    ";
        // line 38
        echo twig_include($this->env, $context, "blog/_rss.html.twig");
        echo "
";
        
        $__internal_ece89ae6efc46d54a7ac6bfd0a946cbdccf09edf9723d51785947e28f447af8e->leave($__internal_ece89ae6efc46d54a7ac6bfd0a946cbdccf09edf9723d51785947e28f447af8e_prof);

        
        $__internal_2a220b75f4c6d3710e7fd70bc24ea0b5b72787da8707da3ae7429cd7be082cba->leave($__internal_2a220b75f4c6d3710e7fd70bc24ea0b5b72787da8707da3ae7429cd7be082cba_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 38,  181 => 37,  175 => 35,  166 => 34,  152 => 29,  149 => 28,  147 => 27,  144 => 26,  135 => 24,  119 => 21,  114 => 19,  108 => 16,  104 => 15,  96 => 10,  92 => 9,  88 => 7,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'blog_index' %}

{% block main %}
    {% for post in posts %}
        <article class=\"post\">
            <h2>
                <a href=\"{{ path('blog_post', {slug: post.slug}) }}\">
                    {{ post.title }}
                </a>
            </h2>

            <p class=\"post-metadata\">
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}</span>
                <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.author.fullName }}</span>
            </p>

            {{ post.summary|md2html }}

            {{ include('blog/_post_tags.html.twig') }}
        </article>
    {% else %}
        <div class=\"well\">{{ 'post.no_posts_found'|trans }}</div>
    {% endfor %}

    {% if posts.haveToPaginate %}
        <div class=\"navigation text-center\">
            {{ pagerfanta(posts, 'twitter_bootstrap3_translated', {routeName: 'blog_index_paginated'}) }}
        </div>
    {% endif %}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
    {{ include('blog/_rss.html.twig') }}
{% endblock %}
", "blog/index.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/app/Resources/views/blog/index.html.twig");
    }
}
