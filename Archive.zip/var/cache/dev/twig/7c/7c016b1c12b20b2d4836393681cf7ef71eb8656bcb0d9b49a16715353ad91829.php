<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_01659279fbed7fa9155732aa8d7bfb335f00846980db16a7529658d7d12f31f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79e23f6234e331d305db5a7b5e6c6931697f916760c029cd523b89f2082371f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79e23f6234e331d305db5a7b5e6c6931697f916760c029cd523b89f2082371f8->enter($__internal_79e23f6234e331d305db5a7b5e6c6931697f916760c029cd523b89f2082371f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_6ff4aa39d076f2a9dc369d8c230de3bca59c19ad3f8cf48f6026187c07ce8f2e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ff4aa39d076f2a9dc369d8c230de3bca59c19ad3f8cf48f6026187c07ce8f2e->enter($__internal_6ff4aa39d076f2a9dc369d8c230de3bca59c19ad3f8cf48f6026187c07ce8f2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_79e23f6234e331d305db5a7b5e6c6931697f916760c029cd523b89f2082371f8->leave($__internal_79e23f6234e331d305db5a7b5e6c6931697f916760c029cd523b89f2082371f8_prof);

        
        $__internal_6ff4aa39d076f2a9dc369d8c230de3bca59c19ad3f8cf48f6026187c07ce8f2e->leave($__internal_6ff4aa39d076f2a9dc369d8c230de3bca59c19ad3f8cf48f6026187c07ce8f2e_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_07b7ce0dc75994287e9a0c26e14a0c5f62d94d1560ab915d2b03eab61bcd562d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_07b7ce0dc75994287e9a0c26e14a0c5f62d94d1560ab915d2b03eab61bcd562d->enter($__internal_07b7ce0dc75994287e9a0c26e14a0c5f62d94d1560ab915d2b03eab61bcd562d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_a82633cd2b437e0ebaf0bfb74601b167c27ef85c427de42fe3f62a6e19fb3a65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a82633cd2b437e0ebaf0bfb74601b167c27ef85c427de42fe3f62a6e19fb3a65->enter($__internal_a82633cd2b437e0ebaf0bfb74601b167c27ef85c427de42fe3f62a6e19fb3a65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_a82633cd2b437e0ebaf0bfb74601b167c27ef85c427de42fe3f62a6e19fb3a65->leave($__internal_a82633cd2b437e0ebaf0bfb74601b167c27ef85c427de42fe3f62a6e19fb3a65_prof);

        
        $__internal_07b7ce0dc75994287e9a0c26e14a0c5f62d94d1560ab915d2b03eab61bcd562d->leave($__internal_07b7ce0dc75994287e9a0c26e14a0c5f62d94d1560ab915d2b03eab61bcd562d_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_2fea65fe8c60988c511b6940cd6cd0fecc8f812049c09f6221c27da4cd914f6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fea65fe8c60988c511b6940cd6cd0fecc8f812049c09f6221c27da4cd914f6d->enter($__internal_2fea65fe8c60988c511b6940cd6cd0fecc8f812049c09f6221c27da4cd914f6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8ab299c26b197f4f3ffb8998064c362b13d262f97809c03d0fb8fcb171bc07da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ab299c26b197f4f3ffb8998064c362b13d262f97809c03d0fb8fcb171bc07da->enter($__internal_8ab299c26b197f4f3ffb8998064c362b13d262f97809c03d0fb8fcb171bc07da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_8ab299c26b197f4f3ffb8998064c362b13d262f97809c03d0fb8fcb171bc07da->leave($__internal_8ab299c26b197f4f3ffb8998064c362b13d262f97809c03d0fb8fcb171bc07da_prof);

        
        $__internal_2fea65fe8c60988c511b6940cd6cd0fecc8f812049c09f6221c27da4cd914f6d->leave($__internal_2fea65fe8c60988c511b6940cd6cd0fecc8f812049c09f6221c27da4cd914f6d_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
