<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_f3ffd5db7db72c7a3d6bda8983623a781373ceb0c5ef38b38ba10669899e1b8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f69f1f419bf3d0186d0dc5ed482c6fd933b1498d3c53c8ca923127c619df92f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f69f1f419bf3d0186d0dc5ed482c6fd933b1498d3c53c8ca923127c619df92f->enter($__internal_3f69f1f419bf3d0186d0dc5ed482c6fd933b1498d3c53c8ca923127c619df92f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_89f31a3474095060a227b45f6cf72978e27233503e99a05db346a3fdba092206 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89f31a3474095060a227b45f6cf72978e27233503e99a05db346a3fdba092206->enter($__internal_89f31a3474095060a227b45f6cf72978e27233503e99a05db346a3fdba092206_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_3f69f1f419bf3d0186d0dc5ed482c6fd933b1498d3c53c8ca923127c619df92f->leave($__internal_3f69f1f419bf3d0186d0dc5ed482c6fd933b1498d3c53c8ca923127c619df92f_prof);

        
        $__internal_89f31a3474095060a227b45f6cf72978e27233503e99a05db346a3fdba092206->leave($__internal_89f31a3474095060a227b45f6cf72978e27233503e99a05db346a3fdba092206_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/attributes.html.php");
    }
}
