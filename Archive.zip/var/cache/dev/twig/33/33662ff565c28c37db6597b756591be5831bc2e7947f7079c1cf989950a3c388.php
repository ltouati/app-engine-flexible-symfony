<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_2fbe74b2b4b30362000b329faf91c791f3c374125645b6d631c5e32036f1459a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d369850669c6b47b80b3628fefe4d41b66eb76b4b2ada796dcce7b2a7298aafd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d369850669c6b47b80b3628fefe4d41b66eb76b4b2ada796dcce7b2a7298aafd->enter($__internal_d369850669c6b47b80b3628fefe4d41b66eb76b4b2ada796dcce7b2a7298aafd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_00d42f04e0ffd104204bf1ccef3531ebd3d638ee372b01421173772cd312f724 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00d42f04e0ffd104204bf1ccef3531ebd3d638ee372b01421173772cd312f724->enter($__internal_00d42f04e0ffd104204bf1ccef3531ebd3d638ee372b01421173772cd312f724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_d369850669c6b47b80b3628fefe4d41b66eb76b4b2ada796dcce7b2a7298aafd->leave($__internal_d369850669c6b47b80b3628fefe4d41b66eb76b4b2ada796dcce7b2a7298aafd_prof);

        
        $__internal_00d42f04e0ffd104204bf1ccef3531ebd3d638ee372b01421173772cd312f724->leave($__internal_00d42f04e0ffd104204bf1ccef3531ebd3d638ee372b01421173772cd312f724_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_widget.html.php");
    }
}
