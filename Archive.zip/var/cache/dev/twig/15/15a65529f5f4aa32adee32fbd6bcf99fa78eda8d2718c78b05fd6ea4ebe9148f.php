<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_b3ad3a06c01bfb6daa8dff72f699ad529ef324506f61ffeff398eff079db95f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de0db2adb33681a0a4f7a69580ad0ca5b04cd2fdcfa009f4da5d6354ff0da69e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de0db2adb33681a0a4f7a69580ad0ca5b04cd2fdcfa009f4da5d6354ff0da69e->enter($__internal_de0db2adb33681a0a4f7a69580ad0ca5b04cd2fdcfa009f4da5d6354ff0da69e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_7fd8cb1d0e2d8efc941839c24bf884770b43e9ac386b4aa8ce742f629c4fbf6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fd8cb1d0e2d8efc941839c24bf884770b43e9ac386b4aa8ce742f629c4fbf6b->enter($__internal_7fd8cb1d0e2d8efc941839c24bf884770b43e9ac386b4aa8ce742f629c4fbf6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_de0db2adb33681a0a4f7a69580ad0ca5b04cd2fdcfa009f4da5d6354ff0da69e->leave($__internal_de0db2adb33681a0a4f7a69580ad0ca5b04cd2fdcfa009f4da5d6354ff0da69e_prof);

        
        $__internal_7fd8cb1d0e2d8efc941839c24bf884770b43e9ac386b4aa8ce742f629c4fbf6b->leave($__internal_7fd8cb1d0e2d8efc941839c24bf884770b43e9ac386b4aa8ce742f629c4fbf6b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/email_widget.html.php");
    }
}
