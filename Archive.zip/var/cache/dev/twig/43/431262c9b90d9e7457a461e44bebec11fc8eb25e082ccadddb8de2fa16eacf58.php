<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_919d07015dde6169379964109e4ba82092bb92ac7bf558b78aa1f7e53fcfbb44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83ce4453bdd80cce94c42ab01ce48e82f43ee3a68d166f0faadc68b5c087fe01 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83ce4453bdd80cce94c42ab01ce48e82f43ee3a68d166f0faadc68b5c087fe01->enter($__internal_83ce4453bdd80cce94c42ab01ce48e82f43ee3a68d166f0faadc68b5c087fe01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_0ef8e8e59733bd473cc4ddbe36dc401855550943664de7a2dc460c206a7a5725 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ef8e8e59733bd473cc4ddbe36dc401855550943664de7a2dc460c206a7a5725->enter($__internal_0ef8e8e59733bd473cc4ddbe36dc401855550943664de7a2dc460c206a7a5725_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_83ce4453bdd80cce94c42ab01ce48e82f43ee3a68d166f0faadc68b5c087fe01->leave($__internal_83ce4453bdd80cce94c42ab01ce48e82f43ee3a68d166f0faadc68b5c087fe01_prof);

        
        $__internal_0ef8e8e59733bd473cc4ddbe36dc401855550943664de7a2dc460c206a7a5725->leave($__internal_0ef8e8e59733bd473cc4ddbe36dc401855550943664de7a2dc460c206a7a5725_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
