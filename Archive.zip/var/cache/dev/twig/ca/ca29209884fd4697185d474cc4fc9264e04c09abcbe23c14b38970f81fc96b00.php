<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_3173a8a02fb49f60eef7db883a9dd8b671834dea37853a9672f2d2772696620b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c04dd7f47d8eb3ac7307b69493a95ceb09672f7b5dbdbf94732f2b6c59c1470 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c04dd7f47d8eb3ac7307b69493a95ceb09672f7b5dbdbf94732f2b6c59c1470->enter($__internal_1c04dd7f47d8eb3ac7307b69493a95ceb09672f7b5dbdbf94732f2b6c59c1470_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_d38e7e8e0a597d81375cadfce840334b38f775610c6aec10c362945eeb811b8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d38e7e8e0a597d81375cadfce840334b38f775610c6aec10c362945eeb811b8e->enter($__internal_d38e7e8e0a597d81375cadfce840334b38f775610c6aec10c362945eeb811b8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_1c04dd7f47d8eb3ac7307b69493a95ceb09672f7b5dbdbf94732f2b6c59c1470->leave($__internal_1c04dd7f47d8eb3ac7307b69493a95ceb09672f7b5dbdbf94732f2b6c59c1470_prof);

        
        $__internal_d38e7e8e0a597d81375cadfce840334b38f775610c6aec10c362945eeb811b8e->leave($__internal_d38e7e8e0a597d81375cadfce840334b38f775610c6aec10c362945eeb811b8e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/Users/ltouati/Documents/prototypes/gae/flexible/sf/symfony_demo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/collection_widget.html.php");
    }
}
